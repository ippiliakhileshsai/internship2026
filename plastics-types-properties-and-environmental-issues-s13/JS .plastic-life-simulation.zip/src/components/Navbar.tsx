import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Home, BookOpen, Trophy, ShieldAlert, User, Compass } from 'lucide-react';

interface NavItem {
  path: string;
  label: string;
  icon: React.ComponentType<any>;
}

const navItems: NavItem[] = [
  { path: '/', label: 'Home', icon: Compass },
  { path: '/learn', label: 'Learn', icon: BookOpen },
  { path: '/challenge', label: 'Challenge', icon: Trophy },
  { path: '/profile', label: 'Profile', icon: User },
];

export const Navbar: React.FC = () => {
  const location = useLocation();
  const currentPath = location.pathname;
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  return (
    <div className="fixed bottom-6 left-0 right-0 z-50 flex justify-center px-4">
      <nav className="glass-panel w-full max-w-sm md:max-w-md rounded-2xl px-3 py-2 flex justify-around items-center shadow-[0_8px_32px_rgba(2,6,23,0.8)] border border-white/10 relative overflow-visible">
        {navItems.map((item, idx) => {
          // Robust checking of active state:
          // Home page is active if path is precisely "/"
          // Others match if the current path starts with or is equal to the target path
          const isActive = item.path === '/' 
            ? currentPath === '/' 
            : currentPath.startsWith(item.path);

          return (
            <Link
              key={item.path}
              to={item.path}
              className="relative py-2.5 px-3 md:px-5 flex flex-col items-center justify-center rounded-xl transition-all duration-300 group outline-none select-none"
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
            >
              {/* Active Glow/Bubble background under clicked item */}
              {isActive && (
                <motion.div
                  layoutId="active-bg"
                  className="absolute inset-0 bg-eco-500/15 rounded-xl border border-eco-500/20"
                  transition={{ type: 'spring', stiffness: 350, damping: 28 }}
                />
              )}

              {/* Hover Glow background under cursor */}
              <AnimatePresence>
                {hoveredIdx === idx && !isActive && (
                  <motion.div
                    layoutId="hover-glow"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="absolute inset-0 bg-white/5 rounded-xl border border-white/5"
                    transition={{ duration: 0.15 }}
                  />
                )}
              </AnimatePresence>

              {/* Icon & Label container */}
              <div 
                className={`relative z-10 flex flex-col items-center transition-all duration-300 ${
                  isActive 
                    ? 'text-eco-400 scale-105' 
                    : 'text-dark-100/60 group-hover:text-eco-300 group-hover:scale-105'
                }`}
              >
                <div className="flex items-center justify-center p-1 relative">
                  <item.icon size={21} className="transition-transform duration-300" />
                  {/* Additional active particle glow */}
                  {isActive && (
                    <span className="absolute -top-1 -right-1 flex h-1.5 w-1.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-eco-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-eco-500"></span>
                    </span>
                  )}
                </div>
                <span className="text-[10px] md:text-xs font-display font-medium tracking-wide mt-0.5 select-none">
                  {item.label}
                </span>
              </div>

              {/* Glowing active notch indicator at the bottom */}
              {isActive && (
                <motion.div
                  layoutId="active-notch"
                  className="absolute -bottom-1 left-1/2 -translate-x-1/2 h-1 w-6 bg-gradient-to-r from-eco-400 to-emerald-500 rounded-full shadow-[0_0_12px_rgba(52,211,153,0.8)]"
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                />
              )}
            </Link>
          );
        })}
      </nav>
    </div>
  );
};
