export interface User {
  name: string;
  email: string;
  avatarSeed: string;
  level: number;
  xp: number;
  streak: number;
  completedChallenges: number[]; // challenge IDs
  savedTopics: number[]; // topic IDs
  bio?: string;
  joinedDate?: string;
}

export interface ChallengeItem {
  id: number;
  title: string;
  xp: number;
  diff: 'Easy' | 'Medium' | 'Hard';
  category: string;
  desc: string;
  duration: string;
  impact: string;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  answer: number; // index of the correct option
  explanation: string;
}

export interface TopicItem {
  id: number;
  title: string;
  category: 'Pollution' | 'Recycling' | 'Biodegradable' | 'Habits';
  readTime: string;
  desc: string;
  content: string[];
  points: number;
  quiz?: QuizQuestion;
}
