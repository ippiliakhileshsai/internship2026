import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, pass: string) => { success: boolean; error?: string };
  signup: (name: string, email: string, pass: string) => { success: boolean; error?: string };
  logout: () => void;
  updateProfile: (name: string, bio: string) => void;
  addXP: (amount: number) => void;
  toggleChallengeCompletion: (challengeId: number, xp: number) => void;
  toggleSavedTopic: (topicId: number) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Try to load active session first
    const activeSession = localStorage.getItem('plastic_sim_session');
    if (activeSession) {
      try {
        setUser(JSON.parse(activeSession));
      } catch (e) {
        localStorage.removeItem('plastic_sim_session');
      }
    } else {
      // Seed a default mock user for quick review if desired, or let users sign up
      // For this app, let's provide a helpful pre-existing Eco Warrior login credentials
      // But don't auto-log in immediately, let them do it or sign up.
      const usersList = localStorage.getItem('plastic_sim_users');
      if (!usersList) {
        const demoUserPass = 'sustainability123';
        const demoUser: User & { password?: string } = {
          name: 'Eco Warrior Sumit',
          email: 'saisumitpanigrahi@gmail.com',
          avatarSeed: 'warrior',
          level: 3,
          xp: 140,
          streak: 5,
          completedChallenges: [1],
          savedTopics: [2],
          bio: 'Restoring ecosystems in a digital age. Proud volunteer and sustainability developer.',
          joinedDate: 'June 2026',
          password: demoUserPass
        };
        localStorage.setItem('plastic_sim_users', JSON.stringify([{ ...demoUser }]));
      }
    }
    setLoading(false);
  }, []);

  const login = (email: string, pass: string) => {
    const rawUsers = localStorage.getItem('plastic_sim_users') || '[]';
    try {
      const users = JSON.parse(rawUsers);
      const matched = users.find((u: any) => u.email.toLowerCase() === email.toLowerCase() && u.password === pass);
      if (matched) {
        // Exclude password from active state
        const { password, ...activeUser } = matched;
        localStorage.setItem('plastic_sim_session', JSON.stringify(activeUser));
        setUser(activeUser);
        return { success: true };
      }
      return { success: false, error: 'Invalid email or password.' };
    } catch (e) {
      return { success: false, error: 'System error. Please retry.' };
    }
  };

  const signup = (name: string, email: string, pass: string) => {
    const rawUsers = localStorage.getItem('plastic_sim_users') || '[]';
    try {
      const users = JSON.parse(rawUsers);
      const exists = users.some((u: any) => u.email.toLowerCase() === email.toLowerCase());
      if (exists) {
        return { success: false, error: 'An account with this email already exists.' };
      }

      const newUser: User = {
        name,
        email,
        avatarSeed: Math.random().toString(36).substring(7),
        level: 1,
        xp: 0,
        streak: 1,
        completedChallenges: [],
        savedTopics: [],
        bio: 'Just started my bio-simulation journey to reduce plastic!',
        joinedDate: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
      };

      const extendedUser = { ...newUser, password: pass };
      users.push(extendedUser);
      localStorage.setItem('plastic_sim_users', JSON.stringify(users));
      
      // Auto-log in
      localStorage.setItem('plastic_sim_session', JSON.stringify(newUser));
      setUser(newUser);
      return { success: true };
    } catch (e) {
      return { success: false, error: 'Sign up failed.' };
    }
  };

  const logout = () => {
    localStorage.removeItem('plastic_sim_session');
    setUser(null);
  };

  const updateProfile = (name: string, bio: string) => {
    if (!user) return;
    const updated = { ...user, name, bio };
    setUser(updated);
    localStorage.setItem('plastic_sim_session', JSON.stringify(updated));

    // Also update in registered user listing
    const rawUsers = localStorage.getItem('plastic_sim_users') || '[]';
    try {
      const users = JSON.parse(rawUsers);
      const index = users.findIndex((u: any) => u.email.toLowerCase() === user.email.toLowerCase());
      if (index !== -1) {
        users[index] = { ...users[index], name, bio };
        localStorage.setItem('plastic_sim_users', JSON.stringify(users));
      }
    } catch (e) {
      console.warn(e);
    }
  };

  const addXP = (amount: number) => {
    if (!user) return;
    let nextXP = user.xp + amount;
    let nextLevel = user.level;
    // Simple level progression: 300 XP per level
    const xpPerLevel = 300;
    while (nextXP >= xpPerLevel) {
      nextXP -= xpPerLevel;
      nextLevel += 1;
    }

    const updated = { ...user, xp: nextXP, level: nextLevel };
    setUser(updated);
    localStorage.setItem('plastic_sim_session', JSON.stringify(updated));

    // Sync in listing
    const rawUsers = localStorage.getItem('plastic_sim_users') || '[]';
    try {
      const users = JSON.parse(rawUsers);
      const index = users.findIndex((u: any) => u.email.toLowerCase() === user.email.toLowerCase());
      if (index !== -1) {
        users[index] = { ...users[index], xp: nextXP, level: nextLevel };
        localStorage.setItem('plastic_sim_users', JSON.stringify(users));
      }
    } catch (e) {
      console.warn(e);
    }
  };

  const toggleChallengeCompletion = (challengeId: number, xpValue: number) => {
    if (!user) return;
    const isCompleted = user.completedChallenges.includes(challengeId);
    let nextCompleted = [...user.completedChallenges];
    let xpGain = 0;

    if (isCompleted) {
      nextCompleted = nextCompleted.filter(id => id !== challengeId);
      xpGain = -xpValue; // deduct XP if unchecked
    } else {
      nextCompleted.push(challengeId);
      xpGain = xpValue;
    }

    let nextXP = user.xp + xpGain;
    let nextLevel = user.level;
    const xpPerLevel = 300;

    if (xpGain > 0) {
      while (nextXP >= xpPerLevel) {
        nextXP -= xpPerLevel;
        nextLevel += 1;
      }
    } else if (xpGain < 0) {
      while (nextXP < 0 && nextLevel > 1) {
        nextLevel -= 1;
        nextXP += xpPerLevel;
      }
      if (nextXP < 0) nextXP = 0;
    }

    // Update streak if a task was successfully completed
    let streakIncrement = 0;
    if (!isCompleted && user.completedChallenges.length === 0) {
      streakIncrement = 1; // first challenge of this session increment streak
    }

    const updated = { 
      ...user, 
      completedChallenges: nextCompleted, 
      xp: nextXP, 
      level: nextLevel,
      streak: user.streak + streakIncrement
    };
    setUser(updated);
    localStorage.setItem('plastic_sim_session', JSON.stringify(updated));

    // Sync in listing
    const rawUsers = localStorage.getItem('plastic_sim_users') || '[]';
    try {
      const users = JSON.parse(rawUsers);
      const index = users.findIndex((u: any) => u.email.toLowerCase() === user.email.toLowerCase());
      if (index !== -1) {
        users[index] = { 
          ...users[index], 
          completedChallenges: nextCompleted,
          xp: nextXP,
          level: nextLevel,
          streak: user.streak + streakIncrement
        };
        localStorage.setItem('plastic_sim_users', JSON.stringify(users));
      }
    } catch (e) {
      console.warn(e);
    }
  };

  const toggleSavedTopic = (topicId: number) => {
    if (!user) return;
    const isSaved = user.savedTopics.includes(topicId);
    const nextSaved = isSaved 
      ? user.savedTopics.filter(id => id !== topicId)
      : [...user.savedTopics, topicId];

    const updated = { ...user, savedTopics: nextSaved };
    setUser(updated);
    localStorage.setItem('plastic_sim_session', JSON.stringify(updated));

    // Sync in listing
    const rawUsers = localStorage.getItem('plastic_sim_users') || '[]';
    try {
      const users = JSON.parse(rawUsers);
      const index = users.findIndex((u: any) => u.email.toLowerCase() === user.email.toLowerCase());
      if (index !== -1) {
        users[index] = { ...users[index], savedTopics: nextSaved };
        localStorage.setItem('plastic_sim_users', JSON.stringify(users));
      }
    } catch (e) {
      console.warn(e);
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading, 
      login, 
      signup, 
      logout, 
      updateProfile, 
      addXP, 
      toggleChallengeCompletion, 
      toggleSavedTopic 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
