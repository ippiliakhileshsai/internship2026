import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Shield, Mail, Lock, Eye, EyeOff, Leaf, ArrowRight, Info } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const Login: React.FC = () => {
  const { login, user } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  // If already logged in, redirect home
  React.useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    setTimeout(() => {
      const response = login(email, password);
      setLoading(false);
      
      if (response.success) {
        navigate('/');
      } else {
        setErrorMsg(response.error || 'Authentication failed. Please retry.');
      }
    }, 600);
  };

  return (
    <div className="min-h-screen bg-dark-950 text-white flex items-center justify-center px-4 py-12 relative overflow-hidden">
      {/* Decorative Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-eco-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-[10%] left-[10%] w-64 h-64 bg-cyan-500/5 rounded-full blur-[100px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="glass-panel w-full max-w-md rounded-3xl p-6 md:p-8 relative border border-white/10 shadow-[0_20px_50px_rgba(2,6,23,0.7)] text-left"
      >
        {/* App Logo & Header */}
        <div className="text-center mb-6">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-eco-500/10 text-eco-400 border border-eco-500/25 mb-3 shadow-[0_0_15px_rgba(34,197,94,0.15)]">
            <Leaf size={24} className="animate-pulse" />
          </div>
          <h2 className="text-2xl md:text-3xl font-display font-bold text-white tracking-tight">Welcome Warrior</h2>
          <p className="text-xs text-dark-100/50 mt-1 uppercase tracking-wider font-mono">Sandbox Simulation Access</p>
        </div>

        {/* Demo Account Callout */}
        <div className="p-3 mb-6 rounded-xl bg-eco-400/5 border border-eco-500/15 text-[11px] md:text-xs text-eco-300 leading-relaxed font-sans max-w-sm mx-auto flex items-start gap-2">
          <Info size={16} className="text-eco-400 shrink-0 mt-0.5" />
          <div>
            <strong>PROPRIETARY DEMO SESSION CREDENTIALS:</strong><br />
            Email: <code className="text-white bg-white/5 px-1 py-0.5 rounded font-mono">saisumitpanigrahi@gmail.com</code> <br />
            Password: <code className="text-white bg-white/5 px-1 py-0.5 rounded font-mono">sustainability123</code>
          </div>
        </div>

        {errorMsg && (
          <div className="p-3 mb-4 rounded-xl bg-red-500/10 text-red-400 text-xs border border-red-500/20 shadow-md">
            ✗ {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email input */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-dark-100/40 uppercase tracking-widest block font-bold">Email address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3.5 text-dark-100/30" size={16} />
              <input
                type="email"
                required
                placeholder="warrior@ecotech.org"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/[0.03] border border-white/10 rounded-xl pl-10 pr-4 py-3 text-xs md:text-sm placeholder-dark-100/20 text-white font-sans focus:outline-none focus:border-eco-400"
              />
            </div>
          </div>

          {/* Password input */}
          <div className="space-y-1">
            <div className="flex justify-between items-center text-[10px] font-mono text-dark-100/40 uppercase tracking-widest font-bold">
              <label>Security Keyphrase</label>
              <Link to="/forgot-password" className="text-eco-400 hover:text-eco-300 hover:underline normal-case tracking-normal font-sans">
                Forgot password?
              </Link>
            </div>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3.5 text-dark-100/30" size={16} />
              <input
                type={showPassword ? "text" : "password"}
                required
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/[0.03] border border-white/10 rounded-xl pl-10 pr-10 py-3 text-xs md:text-sm placeholder-dark-100/20 text-white font-sans focus:outline-none focus:border-eco-400"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-3.5 text-dark-100/30 hover:text-white"
                title={showPassword ? "Hide Keyphrase" : "Reveal Keyphrase"}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {/* Checkboxes */}
          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-dark-100/60 font-sans">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="rounded border-white/10 text-eco-500 bg-white/5 focus:ring-0 focus:ring-offset-0 h-4 w-4"
              />
              <span>Remember environmental session</span>
            </label>
          </div>

          {/* Action button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-eco-500 to-emerald-500 hover:from-eco-400 hover:to-emerald-400 text-dark-950 font-display font-bold px-6 py-3 rounded-xl transition-all shadow-[0_4px_20px_rgba(52,211,153,0.3)] flex items-center justify-center gap-2 group cursor-pointer"
          >
            {loading ? (
              <span className="block h-4 w-4 animate-spin rounded-full border-2 border-dark-950 border-t-transparent" />
            ) : (
              <>
                <span>Access Simulator</span>
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </>
            )}
          </button>
        </form>

        {/* Redirect row */}
        <div className="text-center mt-6 pt-6 border-t border-white/5 text-xs text-dark-100/50">
          <span>New to the simulation protocols? </span>
          <Link to="/signup" className="text-eco-400 hover:text-eco-300 font-bold hover:underline font-display">
            Create Profile Here
          </Link>
        </div>
      </motion.div>
    </div>
  );
};
