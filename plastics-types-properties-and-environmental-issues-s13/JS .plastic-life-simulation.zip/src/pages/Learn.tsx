import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, BookOpen, Star, Sparkles, Filter, 
  HelpCircle, CheckCircle2, AlertCircle, X, Award, MapPin, ListFilter
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { TopicItem } from '../types';

const LEARNING_TOPICS: TopicItem[] = [
  {
    id: 1,
    title: "Microplastics Aquifer Contamination",
    category: "Pollution",
    readTime: "4 mins read",
    desc: "Understanding the dangerous micro-fragmentation of commercial synthetic polymers in biological freshwater streams and human tissue filters.",
    content: [
      "Plastics do not experience true biological decay. Instead, solar UV rays, physical surface abrasion, and wave mechanics fragment them into particles smaller than 5 millimeters, classing them as microplastics.",
      "These particles behave as chemical magnets, adsorbing toxic heavy metals and industrial organo-pollutants from surrounding waters.",
      "As small organisms ingest microplastics, they enter the biological food pyramid, bio-accumulating upward into marine fish, predatory wildlife, crops, and domestic tap water systems.",
      "Mitigation requires physical active capture, advanced biological membrane bioreactors, and a radical source shift away from unnecessary chemical packaging polymer models."
    ],
    points: 40,
    quiz: {
      question: "What primary mechanical process converts large plastic pollutants into dangerous microparticles?",
      options: [
        "Enzymatic digestion by micro-bacteria",
        "Direct chemical crystallization with salts",
        "Solar ultraviolet photolysis and physical wave abrasion",
        "Active volcanic vaporization"
      ],
      answer: 2,
      explanation: "Solar UV radiation combined with physical movement (such as wave action or wind abrasion) fragile-izes plastic structures, fragmenting them into persistent microplastics under 5mm."
    }
  },
  {
    id: 2,
    title: "Deciphering Resin identification Codes (RIC)",
    category: "Recycling",
    readTime: "3 mins read",
    desc: "How to read the chasing arrow symbol codes stamped onto bottles and packaging to ensure proper municipal source separation.",
    content: [
      "The RIC system uses numbers 1 through 7 surrounded by chasing arrows to denote precisely which polymer monomer was used to formulate the package.",
      "RIC 1 (PET/PETE) is highly recyclable and is widely utilized in carbonated beverage bottles.",
      "RIC 2 (HDPE) is sturdy, safe, and often recycled into laundry containers, playground pipes, and robust detergent bottles.",
      "RIC 3 (PVC) and RIC 6 (PS/Polystyrene) are highly toxic to melt down, rarely accepted by standard material processing plants, and present severe endocrine hazards when incinerated."
    ],
    points: 30,
    quiz: {
      question: "Which numerical Resin Identification Code is assigned to HDPE (High-Density Polyethylene)?",
      options: [
        "RIC Code #1",
        "RIC Code #2",
        "RIC Code #4",
        "RIC Code #5"
      ],
      answer: 1,
      explanation: "RIC #1 represents PET/PETE, while RIC #2 represents HDPE. HDPE is sturdily recycled into dense pipes, plastic wood materials, and detergent tubs."
    }
  },
  {
    id: 3,
    title: "Bioplastic Alternatives: PLA vs. PHA Polymers",
    category: "Biodegradable",
    readTime: "5 mins read",
    desc: "Reviewing the chemical differences between starch-derived PLA plastics and bacterial-harvested PHA polymers.",
    content: [
      "Polylactic Acid (PLA) is manufactured from plant starches like corn or sugarcane. Although bio-sourced, it does not biodegrade safely in cold oceans or typical low-temperature home compost piles.",
      "PLA requires strict high-temperature industrial composting processors (exceeding 60°C) to safely breakdown back into carbon dioxide and water.",
      "Polyhydroxyalkanoates (PHAs), however, are naturally synthesized directly by microbes feeding on lipids or glucose. PHAs degrade naturally in marine waters, making them highly resilient alternatives.",
      "To bypass greenwashing, users must verify local recycling rules to confirm if industrial PLA facilities operate locally in their cities."
    ],
    points: 50,
    quiz: {
      question: "Why does Polylactic Acid (PLA) bioplastic often fail to biodegrade in domestic garden compost piles?",
      options: [
        "It lacks adequate molecular oxygen",
        "It has been treated with chemical lead coatings",
        "It strictly requires sustained high-heat industrial compost conditions (>60°C)",
        "PLA is actually organic petroleum"
      ],
      answer: 2,
      explanation: "PLA is bio-sourced but compost-restricted. It only breaks down rapidly at high temperatures provided by specialized municipal industrial compost plants."
    }
  },
  {
    id: 4,
    title: "Source-Separation & Contamination Prevention",
    category: "Habits",
    readTime: "3 mins read",
    desc: "Establishing highly optimized household recycling recycling pipelines to eliminate sorting gridlocks.",
    content: [
      "Even if a plastic polymer is technically recyclable, any residues of organic food oils, paste, or sugar can ruin an entire processed batch of raw polymers.",
      "Food grease causes carbonization in raw melting reactors, structural brittleness in recycled pellets, and chemical odors.",
      "Clean source habits prescribe: Rinse containers, crush PET bottles flat to prevent rolling gridlocks on scanner conveyor belts, and separate caps.",
      "Plastic grocery bags (RIC 4 film) must never be mixed in primary blue residential bins because they wrap around rotatory sorting gears, jamming entire plants."
    ],
    points: 45,
    quiz: {
      question: "Why are domestic plastic grocery bags (RIC 4 film) prohibited from standard home blue recycling bins?",
      options: [
        "They melt at lower temperatures than glass",
        "They entangle, wrap, and jam municipal rotatory sorting machinery gear rollers",
        "They are invisible to infrared laser sensors",
        "They contain radioactive materials"
      ],
      answer: 1,
      explanation: "Thin film plastic bags wrap tightly around automated material recovery facility gears, forcing manual shut-downs and posing worker safety hazards."
    }
  }
];

export const Learn: React.FC = () => {
  const { user, toggleSavedTopic, addXP } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  
  // Modal to read topic
  const [activeTopic, setActiveTopic] = useState<TopicItem | null>(null);

  // Quiz active state inside the modal
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizPointsEarned, setQuizPointsEarned] = useState<number[]>(() => {
    // Keep track of which topic quiz has been answered in this session (or load from storage)
    const saved = localStorage.getItem('plastic_quiz_finished');
    return saved ? JSON.parse(saved) : [];
  });

  const handleQuizSubmit = (topic: TopicItem) => {
    if (selectedOption === null || !topic.quiz) return;
    setQuizSubmitted(true);
    
    if (selectedOption === topic.quiz.answer) {
      // Correct! Add points
      if (!quizPointsEarned.includes(topic.id)) {
        const nextPoints = [...quizPointsEarned, topic.id];
        setQuizPointsEarned(nextPoints);
        localStorage.setItem('plastic_quiz_finished', JSON.stringify(nextPoints));
        
        // Add actual global XP
        addXP(topic.points);
      }
    }
  };

  const categories = ['All', 'Pollution', 'Recycling', 'Biodegradable', 'Habits'];

  const filteredTopics = LEARNING_TOPICS.filter(t => {
    const matchesCategory = selectedCategory === 'All' || t.category === selectedCategory;
    const matchesSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          t.desc.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Calculate learning progress based on completed quizzes
  const percentCompleted = Math.round((quizPointsEarned.length / LEARNING_TOPICS.length) * 100);

  return (
    <div className="min-h-screen bg-dark-950 text-white pb-32 pt-8 px-4 relative">
      {/* Decorative Glows */}
      <div className="absolute top-20 right-5 w-72 h-72 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-20 left-5 w-72 h-72 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

      <header className="max-w-4xl mx-auto mb-8 mt-4 text-left">
        <div className="flex items-center justify-between gap-4">
          <div>
            <span className="text-eco-400 font-black text-xs uppercase tracking-[0.2em] block mb-2">MODULE DIRECTORY</span>
            <h1 className="text-4xl md:text-5xl font-black uppercase italic tracking-tighter text-white">Sustainability Sandbox</h1>
            <p className="text-slate-400 text-sm md:text-base mt-2">Acquire scientific polymer insights to unlock high-tier simulations.</p>
          </div>
          
          <div className="hidden md:flex flex-col items-end gap-1.5 p-4 bg-white/5 border border-white/10 rounded-2xl max-w-[240px]">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">QUIZ PROGRESS INDEX</span>
            <div className="w-40 bg-white/10 h-2.5 rounded-full overflow-hidden">
              <div 
                className="bg-gradient-to-r from-eco-400 to-cyan-400 h-full transition-all duration-500"
                style={{ width: `${percentCompleted}%` }}
              />
            </div>
            <span className="text-[10px] text-eco-400 font-black font-mono mt-1">{percentCompleted}% MATCHED ({quizPointsEarned.length}/{LEARNING_TOPICS.length})</span>
          </div>
        </div>

        {/* Global Progress Tracking - Mobile */}
        <div className="bg-white/5 border border-white/10 p-4 rounded-2xl mt-6 flex md:hidden items-center justify-between gap-4">
          <div className="flex-1">
            <span className="block text-[10px] font-black uppercase tracking-widest text-slate-500">Sandbox Progress Match</span>
            <span className="text-sm font-bold text-white">{quizPointsEarned.length} Quizzes Completed</span>
          </div>
          <div className="w-24 bg-white/10 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-eco-400 h-full transition-all duration-300"
              style={{ width: `${percentCompleted}%` }}
            />
          </div>
        </div>
      </header>

      {/* Control Panel (Search & Category filter) */}
      <section className="max-w-4xl mx-auto mb-8 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="absolute left-4 top-3.5 text-slate-500" size={18} />
            <input
              type="text"
              placeholder="Search polymer topics, codes, recycling guidelines..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/[0.03] border border-white/10 rounded-xl pl-12 pr-4 py-3 text-sm placeholder-slate-500 text-white font-sans focus:outline-none focus:border-eco-400/50 focus:bg-white/[0.05]"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-3.5 text-slate-500 hover:text-white"
              >
                <X size={16} />
              </button>
            )}
          </div>

          {/* Mobile indicator for category selection label */}
          <div className="flex items-center gap-2 px-3 py-1 bg-white/[0.02] border border-white/5 rounded-xl sm:hidden text-xs text-slate-400">
            <ListFilter size={14} />
            <span>Swipe categories to filter</span>
          </div>
        </div>

        {/* Category tags */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none snap-x select-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs md:text-sm font-black uppercase tracking-wider transition-all duration-200 snap-center cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-eco-400 text-slate-950 shadow-[0_2px_12px_rgba(34,197,94,0.3)] border border-transparent'
                  : 'bg-white/5 border border-white/10 hover:bg-white/10 text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* Grid of cards */}
      <main className="max-w-4xl mx-auto">
        {filteredTopics.length === 0 ? (
          <div className="text-center py-16 bg-white/5 border border-white/10 rounded-[2rem] p-8">
            <BookOpen className="mx-auto text-slate-600 mb-4" size={48} />
            <h3 className="text-lg font-bold text-white uppercase tracking-tight">No scientific sandboxes found</h3>
            <p className="text-slate-400 text-sm mt-1">Try modifying your search criteria or resetting your directory tags.</p>
            <button 
              onClick={() => { setSearchQuery(''); setSelectedCategory('All'); }}
              className="mt-4 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-semibold"
            >
              Reset Directories
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <AnimatePresence mode="popLayout">
              {filteredTopics.map((topic) => {
                const isSaved = user?.savedTopics.includes(topic.id);
                const quizDone = quizPointsEarned.includes(topic.id);
                
                return (
                  <motion.div
                    key={topic.id}
                    layoutId={`topic-card-${topic.id}`}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="bg-white/5 backdrop-blur-lg border border-white/10 p-6 rounded-[2rem] flex flex-col justify-between hover:border-eco-500/30 transition-all group"
                  >
                    <div>
                      {/* Badge / Save Row */}
                      <div className="flex items-center justify-between gap-2 mb-4">
                        <span className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded w-fit ${
                          topic.category === 'Pollution' ? 'bg-red-500/10 text-red-100 border border-red-500/20' :
                          topic.category === 'Recycling' ? 'bg-cyan-500/10 text-cyan-200 border border-cyan-500/20' :
                          topic.category === 'Biodegradable' ? 'bg-eco-500/10 text-eco-200 border border-eco-500/20' :
                          'bg-amber-500/10 text-amber-100 border border-amber-500/20'
                        }`}>
                          {topic.category}
                        </span>
                        
                        <div className="flex items-center gap-1">
                          <span className="text-[10px] font-mono text-slate-500">{topic.readTime}</span>
                          {user && (
                            <button
                              onClick={(e) => {
                                  e.stopPropagation();
                                  toggleSavedTopic(topic.id);
                                }}
                              className={`p-1.5 rounded-lg transition-colors ${
                                isSaved ? 'text-amber-400 bg-amber-400/5' : 'text-slate-500 hover:text-white'
                              }`}
                              title={isSaved ? "Saved to Profile" : "Bookmark this topic"}
                            >
                              <Star size={14} fill={isSaved ? "currentColor" : "none"} />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Header */}
                      <h3 className="text-xl font-bold uppercase tracking-tight text-white group-hover:text-eco-300 transition-colors mb-2 leading-tight">
                        {topic.title}
                      </h3>
                      <p className="text-slate-400 text-xs md:text-sm font-sans line-clamp-3 leading-relaxed mb-6">
                        {topic.desc}
                      </p>
                    </div>

                    {/* Bottom Read / Quiz status row */}
                    <div className="flex items-center justify-between gap-4 pt-4 border-t border-white/10">
                      <button
                        onClick={() => {
                          setActiveTopic(topic);
                          setSelectedOption(null);
                          setQuizSubmitted(false);
                        }}
                        className="bg-white/5 hover:bg-eco-400 hover:text-slate-950 font-bold text-xs uppercase tracking-tight px-4 py-2.5 rounded-xl transition-all flex items-center gap-1.5"
                      >
                        <span>Open Sandbox</span>
                        <BookOpen size={13} />
                      </button>

                      {quizDone ? (
                        <span className="flex items-center gap-1 text-[10px] font-mono text-eco-400 font-semibold bg-eco-400/5 px-2 py-1 rounded">
                          <CheckCircle2 size={12} /> Claimed +{topic.points} XP
                        </span>
                      ) : (
                        <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                          <HelpCircle size={12} /> Quiz: +{topic.points} XP
                        </span>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </main>

      {/* Topic Reader Modal */}
      <AnimatePresence>
        {activeTopic && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-dark-950/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="glass-panel w-full max-w-2xl max-h-[85vh] rounded-3xl p-6 md:p-8 overflow-y-auto relative shadow-[0_24px_50px_rgba(2,6,23,0.9)] text-left"
            >
              {/* Close Button */}
              <button
                onClick={() => setActiveTopic(null)}
                className="absolute right-4 top-4 p-2 rounded-xl bg-white/5 text-dark-100/60 hover:text-white hover:bg-white/10 transition-colors"
                title="Exit Reader"
              >
                <X size={18} />
              </button>

              {/* Meta */}
              <div className="flex items-center gap-3 mb-4">
                <span className="bg-eco-500/10 text-eco-400 border border-eco-500/20 text-xs font-mono font-bold px-2 py-0.5 rounded uppercase">
                  {activeTopic.category}
                </span>
                <span className="text-xs font-mono text-dark-100/50">{activeTopic.readTime}</span>
              </div>

              {/* Title */}
              <h2 className="text-2xl md:text-3xl font-display font-bold text-white mb-6">
                {activeTopic.title}
              </h2>

              {/* Content sections */}
              <div className="space-y-4 mb-8 text-dark-100/80 text-sm md:text-base leading-relaxed font-sans">
                {activeTopic.content.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>

              {/* Quiz Module */}
              {activeTopic.quiz && (
                <div id="topic-quiz-pane" className="pt-6 border-t border-white/10">
                  <div className="flex items-center gap-2 mb-4 bg-eco-500/5 border border-eco-500/10 p-3 rounded-xl">
                    <Award className="text-eco-400 shrink-0" size={18} />
                    <div>
                      <h4 className="text-xs font-mono uppercase text-eco-400 font-bold">Quiz assessment integration</h4>
                      <p className="text-[11px] text-dark-100/60">Answering this correctly adds <strong className="text-eco-400">+{activeTopic.points} XP</strong> to your active user ecosystem pool.</p>
                    </div>
                  </div>

                  <p className="font-display font-semibold mb-3 text-sm md:text-base">
                    Question: {activeTopic.quiz.question}
                  </p>

                  <div className="space-y-2 mb-4">
                    {activeTopic.quiz.options.map((opt, oIndex) => {
                      const isSelected = selectedOption === oIndex;
                      const isCorrect = oIndex === activeTopic.quiz?.answer;
                      
                      // Background highlights
                      let optClass = "w-full p-3 text-left rounded-xl text-xs md:text-sm transition-all border outline-none cursor-pointer ";
                      if (quizSubmitted) {
                        if (isCorrect) {
                          optClass += "bg-emerald-500/10 text-emerald-400 border-emerald-500/40 shadow-[0_0_12px_rgba(16,185,129,0.1)]";
                        } else if (isSelected) {
                          optClass += "bg-red-500/10 text-red-400 border-red-500/40";
                        } else {
                          optClass += "bg-white/[0.01] text-dark-100/40 border-white/5";
                        }
                      } else {
                        if (isSelected) {
                          optClass += "bg-eco-500/10 text-eco-400 border-eco-500/50 shadow-md";
                        } else {
                          optClass += "bg-white/5 hover:bg-white/10 text-dark-100/80 border-white/5";
                        }
                      }

                      return (
                        <button
                          key={oIndex}
                          disabled={quizSubmitted}
                          onClick={() => setSelectedOption(oIndex)}
                          className={optClass}
                        >
                          <div className="flex items-center justify-between">
                            <span>{opt}</span>
                            {quizSubmitted && isCorrect && <CheckCircle2 className="text-emerald-400 shrink-0" size={16} />}
                            {quizSubmitted && isSelected && !isCorrect && <AlertCircle className="text-red-400 shrink-0" size={16} />}
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Actions / Feedback */}
                  {!quizSubmitted ? (
                    <button
                      onClick={() => handleQuizSubmit(activeTopic)}
                      disabled={selectedOption === null}
                      className="px-6 py-2.5 rounded-xl text-xs font-semibold bg-eco-500 text-dark-950 hover:bg-eco-400 disabled:opacity-40 disabled:hover:bg-eco-500 transition-colors"
                    >
                      Verify Match Answer
                    </button>
                  ) : (
                    <div className="p-4 rounded-xl bg-white/[0.02] border border-white/5 text-xs text-dark-100/60 leading-relaxed">
                      <span className="font-semibold block mb-1 uppercase font-mono text-[10px] text-eco-400">EXPLANATORY PROTOCOL:</span>
                      {activeTopic.quiz.explanation}
                      
                      <div className="mt-3">
                        {selectedOption === activeTopic.quiz.answer ? (
                          <span className="text-emerald-400 font-bold">✓ Success! Experience multipliers credited.</span>
                        ) : (
                          <span className="text-red-400 font-semibold">✗ Incorrect selection. Review topic and retry!</span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Bottom control row */}
              <div className="mt-8 flex justify-end">
                <button
                  onClick={() => setActiveTopic(null)}
                  className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-semibold"
                >
                  Close Module
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
