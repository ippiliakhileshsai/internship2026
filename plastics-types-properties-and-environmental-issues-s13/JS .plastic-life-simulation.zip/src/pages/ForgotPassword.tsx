import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, Mail, ArrowRight, Leaf, HelpCircle, CheckCircle, Info } from 'lucide-react';

export const ForgotPassword: React.FC = () => {
  const [email, setEmail] = useState('');
  const [code, setCode] = useState('');
  const [isSent, setIsSent] = useState(false);
  const [isReset, setIsReset] = useState(false);
  const [newPass, setNewPass] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email) {
      setError('Please provide an email.');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setIsSent(true);
    }, 600);
  };

  const handleReset = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (code !== 'ECO-CODE-2026') {
      setError("Incorrect safety code protocol. Enter precisely: ECO-CODE-2026");
      return;
    }

    if (newPass.length < 6) {
      setError("The new keyphrase must contain at least 6 characters.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      
      // Update in local users listing if the email existed
      const rawUsers = localStorage.getItem('plastic_sim_users') || '[]';
      try {
        const users = JSON.parse(rawUsers);
        const index = users.findIndex((u: any) => u.email.toLowerCase() === email.toLowerCase());
        if (index !== -1) {
          users[index].password = newPass;
          localStorage.setItem('plastic_sim_users', JSON.stringify(users));
        }
      } catch (e) {
        console.warn(e);
      }
      
      setIsReset(true);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-dark-950 text-white flex items-center justify-center px-4 py-12 relative overflow-hidden text-left">
      {/* Decorative Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-eco-500/10 rounded-full blur-[120px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="glass-panel w-full max-w-md rounded-3xl p-6 md:p-8 relative border border-white/10 shadow-[0_20px_50px_rgba(2,6,23,0.7)]"
      >
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-eco-500/10 text-eco-400 border border-eco-500/25 mb-3 shadow-[0_0_15px_rgba(34,197,94,0.15)]">
            <HelpCircle size={24} />
          </div>
          <h2 className="text-2xl md:text-3xl font-display font-bold text-white tracking-tight">Keyphrase Recovery</h2>
          <p className="text-xs text-dark-100/50 mt-1 uppercase tracking-wider font-mono font-medium">Bypass Security Gate</p>
        </div>

        {error && (
          <div className="p-3 mb-4 rounded-xl bg-red-500/10 text-red-00 text-xs border border-red-500/20 shadow-md">
            ✗ {error}
          </div>
        )}

        <AnimatePresence mode="wait">
          {!isSent ? (
            <motion.form
              key="request-form"
              onSubmit={handleSend}
              className="space-y-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className="space-y-1">
                <label className="text-[10px] font-mono text-dark-100/40 uppercase tracking-widest block font-bold">Email address</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3.5 text-dark-100/30" size={16} />
                  <input
                    type="email"
                    required
                    placeholder="warrior@ecotech.org"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-white/[0.03] border border-white/10 rounded-xl pl-10 pr-4 py-3 text-xs md:text-sm placeholder-dark-100/20 text-white font-sans focus:outline-none focus:border-eco-400"
                  />
                </div>
                <p className="text-[10px] text-dark-100/40 leading-normal pt-1 font-sans">
                  The sandbox will emit a simulated satellite override token code to this communication channel.
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-eco-500 to-emerald-500 hover:from-eco-400 hover:to-emerald-400 text-dark-950 font-display font-bold px-6 py-3 rounded-xl transition-all shadow-[0_4px_20px_rgba(52,211,153,0.3)] flex items-center justify-center gap-2 group cursor-pointer"
              >
                {loading ? (
                  <span className="block h-4 w-4 animate-spin rounded-full border-2 border-dark-950 border-t-transparent" />
                ) : (
                  <>
                    <span>Generate Sat-Code</span>
                    <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
                  </>
                )}
              </button>
            </motion.form>
          ) : !isReset ? (
            <motion.form
              key="reset-form"
              onSubmit={handleReset}
              className="space-y-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className="p-3 mb-4 rounded-xl bg-eco-400/5 border border-eco-500/15 text-[11px] md:text-xs text-eco-300 leading-normal flex items-start gap-2">
                <Info size={16} className="text-eco-400 shrink-0 mt-0.5" />
                <div>
                  <strong>SIMULATED SAT DISPATCH SUCCESSFUL:</strong><br />
                  Recovery token dispatched to communications pipeline.<br />
                  Code to type: <code className="text-white bg-white/10 px-1 rounded font-mono font-bold">ECO-CODE-2026</code>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono text-dark-100/40 uppercase tracking-widest block font-bold">Verification Token Code</label>
                <input
                  type="text"
                  required
                  placeholder="ECO-CODE-2026"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full bg-white/[0.03] border border-white/10 rounded-xl p-3 text-xs md:text-sm text-center placeholder-dark-100/20 text-white font-mono uppercase tracking-widest focus:outline-none focus:border-eco-400"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono text-dark-100/40 tracking-widest block font-bold uppercase">New Security Keyphrase</label>
                <input
                  type="password"
                  required
                  placeholder="At least 6 characters"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  className="w-full bg-white/[0.03] border border-white/10 rounded-xl p-3 text-xs md:text-sm placeholder-dark-100/20 text-white font-sans focus:outline-none focus:border-eco-400"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-eco-500 to-emerald-500 hover:from-eco-400 hover:to-emerald-400 text-dark-950 font-display font-bold px-6 py-3 rounded-xl transition-all shadow-[0_4px_20px_rgba(52,211,153,0.3)] flex items-center justify-center gap-2 group cursor-pointer"
              >
                {loading ? (
                  <span className="block h-4 w-4 animate-spin rounded-full border-2 border-dark-950 border-t-transparent" />
                ) : (
                  <>
                    <span>Confirm Keyphrase Override</span>
                    <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
                  </>
                )}
              </button>
            </motion.form>
          ) : (
            <motion.div
              key="success-prompt"
              className="text-center space-y-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <div className="h-12 w-12 rounded-full bg-eco-500/10 border border-eco-500/25 text-eco-400 flex items-center justify-center mx-auto shadow-md">
                <CheckCircle size={24} />
              </div>
              <h3 className="text-lg font-display font-bold">Keyphrase Successfully Reset</h3>
              <p className="text-xs text-dark-100/60 leading-relaxed font-sans pb-2">
                Your sandbox access coordinates have been registered and matched with the new credentials. You can now access your ecological status.
              </p>
              <Link
                to="/login"
                className="block w-full bg-eco-500 hover:bg-eco-400 text-dark-950 text-xs font-bold font-display py-3 rounded-xl shadow-md transition-all text-center"
              >
                Return to Login Gate
              </Link>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Back link */}
        {!isReset && (
          <div className="text-center mt-6 pt-6 border-t border-white/5 text-xs text-dark-100/50">
            <Link to="/login" className="text-eco-400 hover:text-eco-300 hover:underline">
              ← Return To Login Portal
            </Link>
          </div>
        )}
      </motion.div>
    </div>
  );
};
