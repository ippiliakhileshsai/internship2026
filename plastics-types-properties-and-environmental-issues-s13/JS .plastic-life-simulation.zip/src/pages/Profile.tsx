import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, Mail, Calendar, Flame, Award, Trash, Shield, LogOut, Edit3, 
  MapPin, CheckCircle2, Heart, RefreshCw, Star, Info, Save, X 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const Profile: React.FC = () => {
  const { user, logout, updateProfile } = useAuth();
  
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(user?.name || '');
  const [editBio, setEditBio] = useState(user?.bio || '');
  const [successMsg, setSuccessMsg] = useState('');

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-950 text-white flex items-center justify-center p-6">
        <div className="glass-panel max-w-sm p-8 rounded-2xl text-center border border-white/10">
          <Info className="mx-auto text-amber-500 mb-4" size={48} />
          <h2 className="text-xl font-display font-semibold">ECOSYSTEM ENVELOPE SECURE</h2>
          <p className="text-dark-100/60 text-xs mt-2 mb-6">
            Sign in or generate a new session profile to evaluate achievements, inspect levels, and complete eco-tech pledges.
          </p>
        </div>
      </div>
    );
  }

  // Calculate stats based on challenges
  const completedChallengesCount = user.completedChallenges.length;
  const savedTopicsCount = user.savedTopics.length;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim()) return;
    
    updateProfile(editName, editBio);
    setIsEditing(false);
    setSuccessMsg('Profile updated successfully!');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  // Compute stats metrics dynamically
  const nextLevelXpNeeded = 300;
  const percentToNextLevel = Math.round((user.xp / nextLevelXpNeeded) * 100);

  return (
    <div className="min-h-screen bg-dark-950 text-white pb-32 pt-8 px-4 relative">
      {/* Background Decorative Mesh glow */}
      <div className="absolute top-[10%] right-[-10%] w-72 h-72 bg-eco-500/5 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[10%] left-[-10%] w-72 h-72 bg-cyan-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-4xl mx-auto mt-4 text-left">
        <span className="text-eco-400 font-black text-xs uppercase tracking-[0.2em] block mb-2">USER ACCESS WORKSPACE</span>
        <h1 className="text-4xl md:text-5xl font-black uppercase italic tracking-tighter text-white">Warrior Profile</h1>
        <p className="text-slate-400 text-sm md:text-base mt-2">Inspect your scientific progress index, current badges, and active bio data.</p>
      </div>

      <main className="max-w-4xl mx-auto mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6 text-left">
        {/* Left column - Avatar and edit details */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white/5 backdrop-blur-lg border border-white/10 p-6 rounded-[2rem] relative text-center">
            {/* Level badge */}
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-full bg-gradient-to-r from-eco-500 to-emerald-500 text-dark-950 text-xs font-black tracking-wider uppercase shadow-[0_4px_12px_rgba(34,197,94,0.3)]">
              LEVEL {user.level}
            </div>

            {/* Simulated Avatar Sphere */}
            <div className="mt-4 mb-4 flex justify-center">
              <div className="h-24 w-24 rounded-2xl bg-gradient-to-br from-eco-400 via-emerald-500 to-cyan-400 p-0.5 shadow-lg shadow-eco-500/10">
                <div className="w-full h-full rounded-2xl bg-dark-950 flex items-center justify-center text-3xl font-black text-eco-400 font-mono">
                  {user.name.substring(0, 2).toUpperCase()}
                </div>
              </div>
            </div>

            <h3 className="text-2xl font-bold uppercase text-white leading-tight">
              {user.name}
            </h3>
            
            <p className="text-xs text-slate-500 font-mono mt-1 flex items-center justify-center gap-1">
              <Mail size={12} /> {user.email}
            </p>

            <p className="text-xs text-slate-400 font-sans mt-4 italic leading-relaxed px-3 bg-white/[0.01] py-2.5 rounded-xl border border-white/10">
              "{user.bio || 'Eco Warrior dedicated to checking microplastic contamination indexes.'}"
            </p>

            <span className="text-[10px] text-slate-500 font-mono mt-4 block">
              Joined Sandbox: {user.joinedDate || 'June 2026'}
            </span>

            {/* Quick Actions Row */}
            <div className="mt-6 pt-6 border-t border-white/10 flex gap-2">
              <button
                onClick={() => {
                  setEditName(user.name);
                  setEditBio(user.bio || '');
                  setIsEditing(true);
                }}
                className="flex-1 py-2 px-3 bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Edit3 size={13} />
                <span>Edit Info</span>
              </button>
              
              <button
                onClick={logout}
                className="py-2 px-3 bg-red-500/10 hover:bg-red-500 hover:text-white border border-red-500/10 text-red-500 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer"
                title="Sign out of current profile"
              >
                <LogOut size={13} />
                <span>Logout</span>
              </button>
            </div>

            {/* Edit Modal / overlay form inline */}
            <AnimatePresence>
              {isEditing && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-dark-950/95 backdrop-blur-md rounded-[2rem] p-6 flex flex-col justify-between text-left z-20"
                >
                  <form onSubmit={handleSave} className="space-y-4 flex-1 flex flex-col justify-between">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center border-b border-white/10 pb-2">
                        <h4 className="text-xs font-black uppercase text-eco-400 flex items-center gap-1.5">
                          <Edit3 size={14} /> Edit Bio Parameters
                        </h4>
                        <button type="button" onClick={() => setIsEditing(false)} className="text-slate-550 hover:text-white" title="Cancel edits">
                          <X size={16} />
                        </button>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-slate-500 uppercase">Warrior Nickname</label>
                        <input
                          type="text"
                          required
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-eco-400"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-mono text-slate-500 uppercase">Ecosystem Mission/Bio</label>
                        <textarea
                          rows={3}
                          value={editBio}
                          onChange={(e) => setEditBio(e.target.value)}
                          placeholder="Your custom biological mission description..."
                          className="w-full bg-white/5 border border-white/10 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-eco-400 resize-none font-sans"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2 mt-4 pt-4 border-t border-white/10">
                      <button
                        type="button"
                        onClick={() => setIsEditing(false)}
                        className="flex-1 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-xs"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex-1 py-1.5 bg-eco-400 text-slate-950 hover:bg-eco-300 rounded-lg text-xs font-black uppercase"
                      >
                        Save Protocol
                      </button>
                    </div>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Right column - statistics lists, goals progress */}
        <div className="lg:col-span-2 space-y-6">
          {/* Experience level bar card */}
          <div className="bg-white/5 backdrop-blur-lg border border-white/10 p-6 rounded-[2rem]">
            <div className="flex justify-between items-center mb-3">
              <div>
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Experience points progress</span>
                <h4 className="text-xl font-bold uppercase text-white mt-1">Ecosystem Progression</h4>
              </div>
              <span className="font-mono text-xs font-bold text-eco-400 bg-eco-500/10 px-2.5 py-1 rounded-full">
                {user.xp} / 300 XP
              </span>
            </div>

            {/* Progress line */}
            <div className="w-full bg-white/5 h-3 rounded-full overflow-hidden border border-white/10 p-0.5">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${percentToNextLevel}%` }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className="bg-gradient-to-r from-eco-500 to-emerald-400 h-full rounded-full"
              />
            </div>

            <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 mt-2">
              <span>LEVEL {user.level}</span>
              <span>{percentToNextLevel}% toward LEVEL {user.level + 1}</span>
            </div>
          </div>

          {/* Core Metrics Bento Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            <div className="bg-white/5 backdrop-blur-md border border-white/10 p-5 rounded-[2rem] flex flex-col justify-between hover:border-orange-500/30 transition-all">
              <div className="text-orange-400 p-2 rounded-xl bg-orange-400/5 w-fit border border-orange-500/10">
                <Flame size={20} fill="currentColor" />
              </div>
              <div className="mt-4">
                <span className="block text-[10px] font-black uppercase tracking-widest text-slate-500">Current Streak</span>
                <span className="text-2xl font-black italic text-white mt-1 block">{user.streak} Days</span>
              </div>
            </div>

            <div className="bg-white/5 backdrop-blur-md border border-white/10 p-5 rounded-[2rem] flex flex-col justify-between hover:border-eco-400/30 transition-all">
              <div className="text-eco-400 p-2 rounded-xl bg-eco-400/5 w-fit border border-eco-500/10">
                <CheckCircle2 size={20} />
              </div>
              <div className="mt-4">
                <span className="block text-[10px] font-black uppercase tracking-widest text-slate-500">Missions Mastered</span>
                <span className="text-2xl font-black italic text-white mt-1 block">{completedChallengesCount} Pledges</span>
              </div>
            </div>

            <div className="bg-white/5 backdrop-blur-md border border-white/10 p-5 rounded-[2rem] flex flex-col justify-between col-span-2 sm:col-span-1 hover:border-cyan-400/30 transition-all">
              <div className="text-cyan-400 p-2 rounded-xl bg-cyan-400/5 w-fit border border-cyan-500/10">
                <Star size={20} fill="currentColor" />
              </div>
              <div className="mt-4">
                <span className="block text-[10px] font-black uppercase tracking-widest text-slate-500">Starred Sandboxes</span>
                <span className="text-2xl font-black italic text-white mt-1 block">{savedTopicsCount} Modules</span>
              </div>
            </div>
          </div>

          {/* Success toast message */}
          {successMsg && (
            <div className="p-4 rounded-xl bg-emerald-500/10 text-emerald-400 text-xs border border-emerald-500/20 shadow-md">
              ✓ {successMsg}
            </div>
          )}

          {/* Earned Achievements Trophies */}
          <div className="bg-white/5 backdrop-blur-lg border border-white/10 p-6 rounded-[2rem]">
            <h4 className="text-lg font-bold uppercase tracking-tight text-white mb-4">My Dynamic Achievements</h4>

            <div className="space-y-3">
              {[
                { name: 'Eco-System Cadet', requirement: 'Join the simulation platform', holds: true, reward: 'Unlocked' },
                { name: 'Polymer Separator', requirement: 'Master 1 separation challenge', holds: completedChallengesCount >= 1, reward: completedChallengesCount >= 1 ? 'Unlocked' : 'Locked' },
                { name: 'Quiz Maestro', requirement: 'Read topics and earn active XP', holds: user.level >= 2, reward: user.level >= 2 ? 'Unlocked' : 'Locked' },
                { name: 'Plastic Sovereign', requirement: 'Sustain a 5-day Streak + Level 3', holds: user.streak >= 5 && user.level >= 3, reward: user.streak >= 5 && user.level >= 3 ? 'Unlocked' : 'Locked' },
              ].map((ach, index) => (
                <div 
                  key={index}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between text-xs transition-colors ${
                    ach.holds 
                      ? 'bg-white/[0.02] border-white/10 hover:bg-white/[0.04]' 
                      : 'bg-white/[0.005] border-white/5 opacity-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-xl ${ach.holds ? 'bg-eco-500/10 text-eco-400 border border-eco-500/20' : 'bg-white/5 text-slate-550'}`}>
                      <Award size={16} />
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-white uppercase text-xs">{ach.name}</p>
                      <p className="text-[10px] text-slate-500">{ach.requirement}</p>
                    </div>
                  </div>

                  <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded ${
                    ach.holds 
                      ? 'bg-eco-400/10 text-eco-400' 
                      : 'bg-white/5 text-slate-550'
                  }`}>
                    {ach.reward}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
