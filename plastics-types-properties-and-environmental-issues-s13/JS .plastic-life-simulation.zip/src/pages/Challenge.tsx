import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, Zap, Flame, Calendar, Clock, CheckCircle2, 
  Lock, Award, Shield, Compass, Heart, AlertCircle, RefreshCw 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ChallengeItem } from '../types';

const DAILY_CHALLENGES: ChallengeItem[] = [
  {
    id: 1,
    title: "Thermos Substitution Override",
    xp: 40,
    diff: "Easy",
    category: "Daily",
    desc: "Refuse single-use beverage containers. Substitute 100% of water/coffee fluids into a reusable thermal flask.",
    duration: "24h limit",
    impact: "0.15kg plastics saved"
  },
  {
    id: 2,
    title: "Grocery Film Lock",
    xp: 50,
    diff: "Easy",
    category: "Daily",
    desc: "Decline all disposable carrier bags. Bring a pre-owned cotton mesh tote to buy grocery ingredients.",
    duration: "24h limit",
    impact: "0.08kg plastics saved"
  },
  {
    id: 3,
    title: "Batch Decontamination Rinse",
    xp: 70,
    diff: "Medium",
    category: "Daily",
    desc: "Scrub and clean remaining sweet yogurt or milk proteins from all raw house packaging prior to placement in municipal recycling bins.",
    duration: "24h limit",
    impact: "0.20kg contamination prevented"
  }
];

const WEEKLY_CHALLENGES: ChallengeItem[] = [
  {
    id: 4,
    title: "Zero-Film Bulk Logistics",
    xp: 130,
    diff: "Medium",
    category: "Weekly",
    desc: "Acquire three dry pantry staples (e.g. rice, beans, rolled oats, sugar) via plastic-free bulk gravity bins using reusable paper storage.",
    duration: "6 days left",
    impact: "0.45kg plastics saved"
  },
  {
    id: 5,
    title: "Thermoset Polymer Audit",
    xp: 180,
    diff: "Hard",
    category: "Weekly",
    desc: "Source and correctly return 3kg of high-density thermoplastics (RIC 2 HDPE milk bottles, soap boxes) to specialized processing facilities.",
    duration: "5 days left",
    impact: "3.00kg recycling synced"
  },
  {
    id: 6,
    title: "Local Ecosystem Watershed sweep",
    xp: 250,
    diff: "Hard",
    category: "Weekly",
    desc: "Scout and physically collect at least 15 separate plastic packaging foils, straws, or cups from local public playgrounds or tributaries.",
    duration: "4 days left",
    impact: "1.20kg collected safely"
  }
];

const EARNABLE_BADGES = [
  { id: 'badge-1', name: 'Zero-Waste Initiate', desc: 'Perform your first challenge completion override', icon: Shield, minLevel: 1, color: 'text-blue-400 bg-blue-500/10' },
  { id: 'badge-2', name: 'Polymer Cleanser', desc: 'Sustain a 5-day streak of perfect separation audits', icon: Flame, minLevel: 2, color: 'text-orange-400 bg-orange-500/10' },
  { id: 'badge-3', name: 'Ecosystem Architect', desc: 'Claim a Hard difficulty challenge milestone', icon: Award, minLevel: 3, color: 'text-eco-400 bg-eco-500/10' },
  { id: 'badge-4', name: 'Carbon Neutral Sovereign', desc: 'Obey all Sandbox Quizzes and hit User Level 5', icon: Trophy, minLevel: 5, color: 'text-purple-400 bg-purple-500/10' }
];

export const Challenge: React.FC = () => {
  const { user, toggleChallengeCompletion } = useAuth();
  const [activeTab, setActiveTab] = useState<'Daily' | 'Weekly' | 'Badges'>('Daily');

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-950 text-white flex items-center justify-center p-6">
        <div className="glass-panel max-w-sm p-8 rounded-2xl text-center border border-white/10">
          <AlertCircle className="mx-auto text-amber-500 mb-4" size={48} />
          <h2 className="text-xl font-display font-semibold">Protected Environmental Portal</h2>
          <p className="text-dark-100/60 text-xs mt-2 mb-6">
            You must register or log into your LocalStorage profile to initialize challenges, save ecological streaks, and gain bio-XP scores.
          </p>
        </div>
      </div>
    );
  }

  // Calculate stats
  const completedDailies = DAILY_CHALLENGES.filter(c => user.completedChallenges.includes(c.id));
  const completedWeeklies = WEEKLY_CHALLENGES.filter(c => user.completedChallenges.includes(c.id));

  const totalCompletedCount = user.completedChallenges.length;
  // Compute approximate saved plastic weight
  const savedPlasticsKg = (
    (user.completedChallenges.includes(1) ? 0.15 : 0) +
    (user.completedChallenges.includes(2) ? 0.08 : 0) +
    (user.completedChallenges.includes(3) ? 0.20 : 0) +
    (user.completedChallenges.includes(4) ? 0.45 : 0) +
    (user.completedChallenges.includes(5) ? 3.00 : 0) +
    (user.completedChallenges.includes(6) ? 1.20 : 0)
  ).toFixed(2);

  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case 'Easy': return 'text-sky-400 bg-sky-500/10 border-sky-500/15';
      case 'Medium': return 'text-amber-400 bg-amber-500/10 border-amber-500/15';
      case 'Hard': return 'text-red-400 bg-red-500/10 border-red-500/15';
      default: return 'text-white bg-white/10 border-white/10';
    }
  };

  return (
    <div className="min-h-screen bg-dark-950 text-white pb-32 pt-8 px-4 relative">
      {/* Decorative Blur Spheres */}
      <div className="absolute top-[20%] left-[-10%] w-64 h-64 bg-eco-500/5 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[20%] right-[-10%] w-80 h-80 bg-purple-500/5 rounded-full blur-[120px] pointer-events-none" />

      {/* Header Grid */}
      <header className="max-w-4xl mx-auto mb-8 mt-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
          {/* Main heading banner */}
          <div className="md:col-span-2 flex flex-col justify-center text-left">
            <span className="text-eco-400 font-black text-xs uppercase tracking-[0.2em] block mb-2">REAL-WORLD CAMPAIGNS</span>
            <h1 className="text-4xl md:text-5xl font-black uppercase italic tracking-tighter text-white">Simulator Missions</h1>
            <p className="text-slate-400 text-sm md:text-base mt-2 leading-relaxed">Gamify physical carbon avoidance. Complete interactive operations to trigger streak multiplier counters.</p>
          </div>

          {/* Quick Stats Mini Grid */}
          <div className="bg-white/5 backdrop-blur-lg border border-white/10 p-5 rounded-[2rem] flex items-center justify-between hover:border-eco-500/30 transition-all">
            <div className="text-left">
              <span className="block text-[10px] font-black uppercase tracking-widest text-slate-500">Ecosystem Health</span>
              <span className="text-3xl font-black italic text-white mt-1 block">{savedPlasticsKg} kg</span>
              <span className="text-[10px] text-eco-400 font-bold block mt-0.5 font-mono">Organic waste prevented</span>
            </div>
            
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-eco-500/10 text-eco-400 border border-eco-500/20 shadow-[0_0_15px_rgba(34,197,94,0.15)]">
              <Flame size={24} className="animate-pulse" />
            </div>
          </div>
        </div>
      </header>

      {/* Gamification Dashboard Cards */}
      <section className="max-w-4xl mx-auto mb-8 grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-2xl text-left relative">
          <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 block">My Streak</span>
          <span className="text-xl font-bold text-orange-400 font-display flex items-center gap-1.5 mt-1">
            <Flame size={16} fill="currentColor" /> {user.streak} Days
          </span>
        </div>

        <div className="bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-2xl text-left">
          <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 block">Experience</span>
          <span className="text-xl font-bold text-eco-400 font-display flex items-center gap-1.5 mt-1">
            <Zap size={16} fill="currentColor" /> {user.xp}/300 XP
          </span>
        </div>

        <div className="bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-2xl text-left">
          <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 block">Active Level</span>
          <span className="text-xl font-bold text-cyan-400 font-display flex items-center gap-1.5 mt-1">
            <Shield size={16} /> Level {user.level}
          </span>
        </div>

        <div className="bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-2xl text-left">
          <span className="text-[10px] font-black uppercase tracking-widest text-slate-500 block">Pledges Active</span>
          <span className="text-xl font-bold text-purple-400 font-display flex items-center gap-1.5 mt-1">
            <Trophy size={16} /> {totalCompletedCount} Sourced
          </span>
        </div>
      </section>

      {/* Tab Selectors */}
      <section className="max-w-4xl mx-auto mb-8">
        <div className="flex border-b border-white/5">
          {(['Daily', 'Weekly', 'Badges'] as const).map((tab) => {
            const isMatch = activeTab === tab;
            let iconElement: React.ReactNode;
            
            if (tab === 'Daily') iconElement = <Clock size={16} />;
            else if (tab === 'Weekly') iconElement = <Calendar size={16} />;
            else iconElement = <Award size={16} />;

            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-3 px-6 text-sm font-semibold flex items-center gap-2 border-b-2 transition-all relative cursor-pointer outline-none select-none ${
                  isMatch 
                    ? 'text-eco-400 border-eco-500 font-bold bg-white/[0.01]' 
                    : 'text-dark-100/50 border-transparent hover:text-white hover:bg-white/[0.005]'
                }`}
              >
                {iconElement}
                <span>{tab} Missions</span>
                {tab === 'Daily' && completedDailies.length > 0 && (
                  <span className="bg-eco-500 text-dark-950 text-[10px] font-bold h-4 px-1 rounded-full flex items-center justify-center font-mono animate-bounce">
                    {completedDailies.length}
                  </span>
                )}
                {tab === 'Weekly' && completedWeeklies.length > 0 && (
                  <span className="bg-eco-500 text-dark-950 text-[10px] font-bold h-4 px-1 rounded-full flex items-center justify-center font-mono">
                    {completedWeeklies.length}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* Main Container */}
      <main className="max-w-4xl mx-auto text-left">
        <AnimatePresence mode="wait">
          {activeTab === 'Daily' && (
            <motion.div
              key="dailies"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              <div className="flex justify-between items-center bg-white/[0.02] border border-white/5 p-4 rounded-xl text-xs text-dark-100/50 mb-4">
                <span className="flex items-center gap-1.5"><Clock size={14} className="text-eco-400" /> Daily missions refresh in sequence every 24 hours.</span>
                <span className="font-mono text-eco-400">STATUS: REFRESHED</span>
              </div>

              {DAILY_CHALLENGES.map((challenge) => {
                const isCompleted = user.completedChallenges.includes(challenge.id);
                
                return (
                  <div
                    key={challenge.id}
                    className={`p-6 rounded-2xl border transition-all duration-300 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6 ${
                      isCompleted 
                        ? 'bg-eco-500/10 border-eco-500/40 shadow-[0_0_15px_rgba(34,197,94,0.06)]' 
                        : 'bg-white/5 border-white/5 hover:border-white/10'
                    }`}
                  >
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center flex-wrap gap-2">
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border uppercase ${getDifficultyColor(challenge.diff)}`}>
                          {challenge.diff}
                        </span>
                        <span className="text-[10px] text-dark-100/40 font-mono flex items-center gap-1"><Clock size={11} /> {challenge.duration}</span>
                        <span className="text-[10px] text-eco-400/80 font-mono bg-eco-500/5 border border-eco-500/10 px-1.5 py-0.5 rounded">{challenge.impact}</span>
                      </div>

                      <h3 className={`text-lg font-display font-bold leading-tight ${isCompleted ? 'text-eco-300 line-through' : 'text-white'}`}>
                        {challenge.title}
                      </h3>
                      <p className="text-dark-100/60 text-xs md:text-sm font-sans max-w-2xl">
                        {challenge.desc}
                      </p>
                    </div>

                    <div className="flex items-center justify-between md:justify-end gap-6 shrink-0 border-t md:border-t-0 border-white/5 pt-4 md:pt-0">
                      <div className="text-left md:text-right">
                        <span className="block text-[10px] font-mono text-dark-100/40">XP VALUE</span>
                        <span className="text-base font-bold text-eco-400 font-display flex items-center gap-1 mt-0.5">
                          <Zap size={14} fill="currentColor" /> +{challenge.xp} XP
                        </span>
                      </div>

                      <button
                        onClick={() => toggleChallengeCompletion(challenge.id, challenge.xp)}
                        className={`p-3 md:p-4 rounded-xl transition-all cursor-pointer outline-none ${
                          isCompleted
                            ? 'bg-eco-500 text-dark-950 font-bold shadow-[0_0_15px_rgba(34,197,94,0.3)]'
                            : 'bg-white/5 text-dark-100/40 hover:text-white hover:bg-white/10 border border-white/5'
                        }`}
                        title={isCompleted ? "Completed" : "Complete Task"}
                      >
                        <CheckCircle2 size={20} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </motion.div>
          )}

          {activeTab === 'Weekly' && (
            <motion.div
              key="weeklies"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              <div className="flex justify-between items-center bg-white/[0.02] border border-white/5 p-4 rounded-xl text-xs text-dark-100/50 mb-4">
                <span className="flex items-center gap-1.5"><Calendar size={14} className="text-purple-400" /> High-tier missions trigger massive carbon avoidance scores.</span>
                <span className="font-mono text-purple-400">CYCLES ACTIVE</span>
              </div>

              {WEEKLY_CHALLENGES.map((challenge) => {
                const isCompleted = user.completedChallenges.includes(challenge.id);
                
                return (
                  <div
                    key={challenge.id}
                    className={`p-6 rounded-2xl border transition-all duration-300 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-6 ${
                      isCompleted 
                        ? 'bg-purple-500/10 border-purple-500/40 shadow-[0_0_15px_rgba(168,85,247,0.06)]' 
                        : 'bg-white/5 border-white/5 hover:border-white/10'
                    }`}
                  >
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center flex-wrap gap-2">
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border uppercase ${getDifficultyColor(challenge.diff)}`}>
                          {challenge.diff}
                        </span>
                        <span className="text-[10px] text-dark-100/40 font-mono flex items-center gap-1"><Calendar size={11} /> {challenge.duration}</span>
                        <span className="text-[10px] text-purple-400/80 font-mono bg-purple-550/5 border border-purple-500/10 px-1.5 py-0.5 rounded">{challenge.impact}</span>
                      </div>

                      <h3 className={`text-lg font-display font-bold leading-tight ${isCompleted ? 'text-purple-300 line-through' : 'text-white'}`}>
                        {challenge.title}
                      </h3>
                      <p className="text-dark-100/60 text-xs md:text-sm font-sans max-w-2xl">
                        {challenge.desc}
                      </p>
                    </div>

                    <div className="flex items-center justify-between md:justify-end gap-6 shrink-0 border-t md:border-t-0 border-white/5 pt-4 md:pt-0">
                      <div className="text-left md:text-right">
                        <span className="block text-[10px] font-mono text-dark-100/40">XP VALUE</span>
                        <span className="text-base font-bold text-purple-400 font-display flex items-center gap-1 mt-0.5">
                          <Zap size={14} fill="currentColor" /> +{challenge.xp} XP
                        </span>
                      </div>

                      <button
                        onClick={() => toggleChallengeCompletion(challenge.id, challenge.xp)}
                        className={`p-3 md:p-4 rounded-xl transition-all cursor-pointer outline-none ${
                          isCompleted
                            ? 'bg-purple-500 text-white font-bold shadow-[0_0_15px_rgba(168,85,247,0.3)]'
                            : 'bg-white/5 text-dark-100/40 hover:text-white hover:bg-white/10 border border-white/5'
                        }`}
                        title={isCompleted ? "Completed" : "Complete Task"}
                      >
                        <CheckCircle2 size={20} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </motion.div>
          )}

          {activeTab === 'Badges' && (
            <motion.div
              key="badges"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 sm:grid-cols-2 gap-4"
            >
              {EARNABLE_BADGES.map((badge) => {
                const isUnlocked = user.level >= badge.minLevel;
                const BIcon = badge.icon;

                return (
                  <div
                    key={badge.id}
                    className={`p-5 rounded-2xl border flex items-start gap-4 transition-all duration-300 ${
                      isUnlocked 
                        ? 'bg-white/[0.03] border-white/10 hover:border-eco-500/20' 
                        : 'bg-white/[0.01] border-white/5 opacity-55'
                    }`}
                  >
                    <div className={`p-3 rounded-xl shrink-0 ${isUnlocked ? badge.color : 'bg-white/5 text-dark-100/30'}`}>
                      {isUnlocked ? <BIcon size={24} /> : <Lock size={24} />}
                    </div>

                    <div className="text-left space-y-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className={`text-base font-display font-semibold ${isUnlocked ? 'text-white' : 'text-dark-100/50'}`}>
                          {badge.name}
                        </h4>
                        {!isUnlocked && (
                          <span className="text-[9px] font-mono bg-white/5 text-dark-100/50 px-1.5 py-0.5 rounded">
                            Req. Lvl {badge.minLevel}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-dark-100/55 leading-normal font-sans">
                        {badge.desc}
                      </p>
                      
                      {isUnlocked ? (
                        <span className="text-[10px] font-mono text-eco-400 font-semibold block pt-1">
                          ✓ Badge Active & Earned
                        </span>
                      ) : (
                        <span className="text-[10px] font-mono text-dark-100/40 block pt-1">
                          🔒 Locked (Locked content index)
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};
