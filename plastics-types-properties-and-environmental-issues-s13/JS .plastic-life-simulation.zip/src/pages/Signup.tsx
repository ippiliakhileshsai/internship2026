import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Shield, Mail, Lock, Eye, EyeOff, Leaf, ArrowRight, User, CheckCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const Signup: React.FC = () => {
  const { signup, user } = useAuth();
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  // If already logged in, redirect home
  React.useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  // Dynamic Password Strength Meter
  const getPasswordStrength = () => {
    if (!password) return { score: 0, label: 'None', color: 'bg-white/10' };
    let score = 0;
    if (password.length >= 8) score += 1;
    if (/[A-Z]/.test(password) && /[a-z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;

    switch (score) {
      case 1: return { score: 1, label: 'Weak Protocol', color: 'bg-red-500 w-1/4' };
      case 2: return { score: 2, label: 'Moderate Seal', color: 'bg-amber-400 w-2/4' };
      case 3: return { score: 3, label: 'Secure Keyphrase', color: 'bg-eco-400 w-3/4' };
      case 4: return { score: 4, label: 'High-Tier Security', color: 'bg-emerald-500 w-full' };
      default: return { score: 0, label: 'Weak', color: 'bg-red-500 w-1/12' };
    }
  };

  const strength = getPasswordStrength();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (password !== confirmPassword) {
      setErrorMsg("Password entries do not match.");
      return;
    }

    if (password.length < 6) {
      setErrorMsg("Password must be at least 6 characters long.");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      const response = signup(name, email, password);
      setLoading(false);
      
      if (response.success) {
        navigate('/');
      } else {
        setErrorMsg(response.error || 'Registration failed. Please retry.');
      }
    }, 600);
  };

  return (
    <div className="min-h-screen bg-dark-950 text-white flex items-center justify-center px-4 py-12 relative overflow-hidden">
      {/* Decorative Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-eco-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[10%] right-[15%] w-64 h-64 bg-cyan-500/5 rounded-full blur-[100px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="glass-panel w-full max-w-md rounded-3xl p-6 md:p-8 relative border border-white/10 shadow-[0_20px_50px_rgba(2,6,23,0.7)] text-left animate-fade-in"
      >
        {/* App Logo & Header */}
        <div className="text-center mb-6">
          <div className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-eco-500/10 text-eco-400 border border-eco-500/25 mb-3 shadow-[0_0_15px_rgba(34,197,94,0.15)]">
            <Leaf size={24} />
          </div>
          <h2 className="text-2xl md:text-3xl font-display font-bold text-white tracking-tight">Create Profile</h2>
          <p className="text-xs text-dark-100/50 mt-1 uppercase tracking-wider font-mono font-medium">Join the ecological sandbox</p>
        </div>

        {errorMsg && (
          <div className="p-3 mb-4 rounded-xl bg-red-500/10 text-red-400 text-xs border border-red-500/20 shadow-md">
            ✗ {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name input */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-dark-100/40 uppercase tracking-widest block font-bold">Warrior Name</label>
            <div className="relative">
              <User className="absolute left-3.5 top-3.5 text-dark-100/30" size={16} />
              <input
                type="text"
                required
                placeholder="Sumit Panigrahi"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-white/[0.03] border border-white/10 rounded-xl pl-10 pr-4 py-3 text-xs md:text-sm placeholder-dark-100/20 text-white font-sans focus:outline-none focus:border-eco-400 font-medium"
              />
            </div>
          </div>

          {/* Email input */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-dark-100/40 uppercase tracking-widest block font-bold">Email address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-3.5 text-dark-100/30" size={16} />
              <input
                type="email"
                required
                placeholder="warrior@ecotech.org"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/[0.03] border border-white/10 rounded-xl pl-10 pr-4 py-3 text-xs md:text-sm placeholder-dark-100/20 text-white font-sans focus:outline-none focus:border-eco-400"
              />
            </div>
          </div>

          {/* Password input */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-dark-100/40 uppercase tracking-widest block font-bold">Security Keyphrase</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3.5 text-dark-100/30" size={16} />
              <input
                type={showPassword ? "text" : "password"}
                required
                placeholder="At least 6 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/[0.03] border border-white/10 rounded-xl pl-10 pr-10 py-3 text-xs md:text-sm placeholder-dark-100/20 text-white font-sans focus:outline-none focus:border-eco-400"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-3.5 text-dark-100/30 hover:text-white"
                title={showPassword ? "Hide Keyphrase" : "Reveal Keyphrase"}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>

            {/* Password strength visual status indicator */}
            {password && (
              <div className="pt-2">
                <div className="flex justify-between items-center text-[9px] font-mono text-dark-100/50 uppercase mb-1">
                  <span>Securing Parameter:</span>
                  <span className="font-bold text-eco-400">{strength.label}</span>
                </div>
                <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                  <div className={`h-full transition-all duration-300 ${strength.color}`} />
                </div>
              </div>
            )}
          </div>

          {/* Confirm Password input */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono text-dark-100/40 uppercase tracking-widest block font-bold">Confirm Keyphrase</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-3.5 text-dark-100/30" size={16} />
              <input
                type="password"
                required
                placeholder="Match original entry"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full bg-white/[0.03] border border-white/10 rounded-xl pl-10 pr-4 py-3 text-xs md:text-sm placeholder-dark-100/20 text-white font-sans focus:outline-none focus:border-eco-400"
              />
            </div>
            {confirmPassword && password !== confirmPassword && (
              <p className="text-[10px] text-red-400 font-mono pt-1">✗ Password entries do not match yet.</p>
            )}
          </div>

          {/* Terms & Conditions agreement */}
          <p className="text-[10px] text-dark-100/30 font-sans leading-relaxed pt-1 select-none">
            By creating a profile, you permit the sandbox to store your levels and eco-stats directly in your browser's LocalStorage system.
          </p>

          {/* Action button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-eco-500 to-emerald-500 hover:from-eco-400 hover:to-emerald-400 text-dark-950 font-display font-bold px-6 py-3 rounded-xl transition-all shadow-[0_4px_20px_rgba(52,211,153,0.3)] flex items-center justify-center gap-2 group cursor-pointer mt-2"
          >
            {loading ? (
              <span className="block h-4 w-4 animate-spin rounded-full border-2 border-dark-950 border-t-transparent" />
            ) : (
              <>
                <span>Initialize Platform Profile</span>
                <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
              </>
            )}
          </button>
        </form>

        {/* Redirect row */}
        <div className="text-center mt-6 pt-6 border-t border-white/5 text-xs text-dark-100/50">
          <span>Already managed a sandbox profile before? </span>
          <Link to="/login" className="text-eco-400 hover:text-eco-300 font-bold hover:underline font-display">
            Access Account
          </Link>
        </div>
      </motion.div>
    </div>
  );
};
