import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  ArrowRight, Leaf, Recycle, HeartHandshake, Award, 
  BarChart3, Sparkles, TrendingUp, AlertTriangle, 
  Users, Activity, ChevronRight, Zap, Target
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const Home: React.FC = () => {
  const { user } = useAuth();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1, 
      transition: { staggerChildren: 0.1 } 
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 25 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { type: "spring", stiffness: 100, damping: 15 }
    }
  };

  const features = [
    {
      icon: AlertTriangle,
      title: "Analyze Plastic Waste",
      desc: "Decode the different plastic polymer types (PET, HDPE, PVC, LDPE) and understand their long-term chemical decay in biology.",
      color: "from-amber-400/20 to-orange-500/20",
      border: "rgba(245, 158, 11, 0.3)"
    },
    {
      icon: Target,
      title: "Interactive Challenges",
      desc: "Complete direct real-world task overrides: reduce single-use plastic, source-separate recycling, and practice compostable logistics.",
      color: "from-emerald-400/20 to-teal-500/20",
      border: "rgba(52, 211, 153, 0.3)"
    },
    {
      icon: TrendingUp,
      title: "Track Your Footprint",
      desc: "Monitor your custom carbon-offset and metric kilograms of plastics prevented from entering local aquifers and landfills.",
      color: "from-blue-400/20 to-indigo-500/20",
      border: "rgba(96, 165, 250, 0.3)"
    },
    {
      icon: Award,
      title: "Earn Eco Achievements",
      desc: "Level up from a 'Novice Consumer' to a 'Sustainability Architect' as you build a clean stream of active daily habit challenges.",
      color: "from-purple-400/20 to-fuchsia-500/20",
      border: "rgba(192, 132, 252, 0.3)"
    },
    {
      icon: HeartHandshake,
      title: "Build Eco Habits",
      desc: "Convert transient carbon choices into lifelong biological benefits. Track and inspect your dynamic streak multiplier.",
      color: "from-rose-400/20 to-pink-500/20",
      border: "rgba(251, 113, 133, 0.3)"
    }
  ];

  return (
    <div className="min-h-screen bg-dark-950 text-white overflow-x-hidden relative">
      {/* Decorative Floating Mesh Glows */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-eco-500/10 blur-[150px] pointer-events-none" />
      <div className="absolute top-[30%] right-[-15%] w-[45%] h-[45%] rounded-full bg-cyan-600/10 blur-[150px] pointer-events-none" />
      <div className="absolute bottom-[10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-emerald-500/5 blur-[120px] pointer-events-none" />

      {/* Hero Section */}
      <section className="relative px-6 pt-16 md:pt-24 pb-16 max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-12">
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={containerVariants}
          className="flex-1 text-left max-w-2xl"
        >
          <motion.div 
            variants={itemVariants}
            className="inline-block px-3 py-1 rounded-full bg-eco-500/10 border border-eco-500/25 text-eco-400 text-[11px] font-black uppercase tracking-widest mb-6"
          >
            Sustainability Simulation v2.4
          </motion.div>

          <motion.h1 
            variants={itemVariants}
            className="text-6xl md:text-8xl font-black leading-[0.85] tracking-tighter uppercase mb-6 italic"
          >
            Plastic Life <br className="hidden md:inline" />
            <span className="text-transparent text-stroke-emerald block py-2 mt-2">
              Simulation
            </span>
          </motion.h1>

          <motion.p 
            variants={itemVariants}
            className="text-slate-400 text-lg max-w-lg mb-8 leading-relaxed"
          >
            Gamify your carbon offset. Enter a micro-simulation ecosystem modeled to analyze waste decay, track and complete plastic elimination challenges, and earn biological impact multipliers.
          </motion.p>

          <motion.div 
            variants={itemVariants}
            className="flex flex-wrap gap-4"
          >
            <Link 
              to={user ? "/challenge" : "/signup"} 
              className="px-8 py-4 bg-eco-400 text-slate-950 font-black rounded-2xl flex items-center gap-3 hover:bg-eco-300 transition-colors uppercase tracking-tight shadow-xl shadow-eco-500/20 group"
            >
              <span>{user ? "Begin Simulator" : "Get Started Now"}</span>
              <ArrowRight size={16} className="transition-transform group-hover:translate-x-1" />
            </Link>

            <Link 
              to="/learn" 
              className="px-8 py-4 bg-slate-800/50 backdrop-blur-md border border-white/10 text-white font-bold rounded-2xl hover:bg-white/10 transition-colors uppercase tracking-tight flex items-center gap-2"
            >
              Explore Sandbox
            </Link>
          </motion.div>

          {/* User Status / Quick Stats Badge */}
          {user && (
            <motion.div 
              variants={itemVariants}
              className="mt-8 flex items-center gap-4 p-4 glass-panel rounded-2xl max-w-sm"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-eco-500/20 text-eco-400 font-bold border border-eco-500/30">
                {user.level}
              </div>
              <div className="flex-1">
                <p className="text-xs text-dark-100/50 uppercase font-mono tracking-wider">Currently Logged In</p>
                <p className="text-sm font-semibold">{user.name}</p>
              </div>
              <Link to="/profile" className="text-eco-400 hover:text-eco-300 text-xs font-display font-medium flex items-center gap-1">
                View Profile <ChevronRight size={14} />
              </Link>
            </motion.div>
          )}
        </motion.div>

        {/* Visual Simulated Widget Element (Interactive Glass Render) */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex-1 w-full max-w-md lg:max-w-none relative mt-8 lg:mt-0"
        >
          {/* Main Visual Simulator Card */}
          <div className="glass-panel p-6 rounded-3xl relative border border-white/10 shadow-[0_20px_50px_rgba(2,6,23,0.4)]">
            <div className="flex justify-between items-center mb-6 border-b border-white/5 pb-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                <span className="font-mono text-xs uppercase tracking-wider text-dark-100/60">SIMULATION ENGINE v2.1</span>
              </div>
              <span className="bg-eco-500/10 text-eco-400 px-2 py-0.5 rounded text-xs font-mono">ECO-LIVE</span>
            </div>

            {/* Virtual Decaying Element UI */}
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold font-display">Polystyrene Coffee Cup</h4>
                  <p className="text-xs text-dark-100/50">Simulated decay timeframe</p>
                </div>
                <div className="text-right">
                  <span className="font-mono text-xs text-red-400 font-bold">500 Years</span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold font-display">Single-Use PET Bottle</h4>
                  <p className="text-xs text-dark-100/50">Simulated decay timeframe</p>
                </div>
                <div className="text-right">
                  <span className="font-mono text-xs text-amber-500 font-bold">450 Years</span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold font-display">Biodegradable PLA Wrap</h4>
                  <p className="text-xs text-dark-100/50">Simulated decay timeframe</p>
                </div>
                <div className="text-right">
                  <span className="font-mono text-xs text-eco-400 font-bold">0.5 Years (Compost)</span>
                </div>
              </div>
            </div>

            {/* Simulated Live counter */}
            <div className="mt-6 pt-4 border-t border-white/5 grid grid-cols-2 gap-4">
              <div className="bg-eco-500/5 p-3 rounded-xl border border-eco-500/10">
                <span className="block text-[10px] text-dark-100/40 uppercase font-mono">My Global XP</span>
                <span className="text-xl font-bold text-eco-400 font-display flex items-center gap-1 mt-1">
                  <Zap size={16} fill="currentColor" /> {user ? user.xp + (user.level - 1) * 300 : "0"} XP
                </span>
              </div>
              <div className="bg-cyan-500/5 p-3 rounded-xl border border-cyan-500/10">
                <span className="block text-[10px] text-dark-100/40 uppercase font-mono">Ocean Save Ratio</span>
                <span className="text-xl font-bold text-cyan-400 font-display flex items-center gap-1 mt-1">
                  <Activity size={16} /> 94.6%
                </span>
              </div>
            </div>
          </div>

          {/* Floating Eco Particle Accents */}
          <div className="absolute -top-6 -right-6 w-16 h-16 rounded-2xl bg-gradient-to-br from-eco-400 to-emerald-600 opacity-25 blur-sm -z-10 animate-bounce" style={{ animationDuration: '6s' }} />
          <div className="absolute -bottom-8 -left-6 w-20 h-20 rounded-full bg-cyan-400 opacity-20 blur-md -z-10 animate-pulse" />
        </motion.div>
      </section>

      {/* Pillars Section */}
      <section className="px-6 py-16 max-w-7xl mx-auto border-t border-white/10 relative">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-eco-400 font-black text-xs uppercase tracking-[0.2em] block mb-4">ECOSYSTEM INTEGRATION</span>
          <h2 className="text-4xl md:text-6xl font-black uppercase italic tracking-tighter text-white">Engineering Sustainability</h2>
          <p className="text-slate-400 mt-4 text-base md:text-lg leading-relaxed">
            Our sandbox coordinates are designated to model environmental decay and teach user-centric footprint reduction through direct behavioral interventions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feat, i) => (
            <motion.div
              key={feat.title}
              whileHover={{ y: -8, transition: { duration: 0.2 } }}
              className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-[2rem] p-8 transition-all relative overflow-hidden group"
              style={{ borderHoverColor: feat.border } as any}
            >
              {/* Inner glowing element */}
              <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full bg-gradient-to-br ${feat.color} blur-xl opacity-30 group-hover:scale-125 transition-transform`} />
              
              <div className="h-12 w-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center mb-6 group-hover:border-eco-500/35 transition-colors">
                <feat.icon className="text-eco-400 group-hover:text-eco-300 transition-colors" size={24} />
              </div>
              <h3 className="text-2xl font-bold tracking-tight mb-2 text-white">{feat.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{feat.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Learning Journey Module */}
      <section className="px-6 py-16 max-w-7xl mx-auto border-t border-white/10 relative">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-eco-400 font-black text-xs uppercase tracking-[0.2em] block mb-4">SIMULATION FLOW</span>
          <h2 className="text-4xl md:text-6xl font-black uppercase italic tracking-tighter text-white">Your Sustainability Pipeline</h2>
          <p className="text-slate-400 mt-4 text-base md:text-lg leading-relaxed">
            Follow our 5-phase gamified track to transition from plastic dependency into carbon neutrality.
          </p>
        </div>

        {/* Dynamic Step Timeline UI */}
        <div className="relative border-l border-white/10 ml-4 md:ml-12 pl-8 md:pl-12 space-y-12 max-w-3xl mx-auto">
          {[
            { phase: "01", step: "Sandbox Selection", detail: "Browse clean modules covering water contamination, micro-plastics ingestion, and polymer chemistry." },
            { phase: "02", step: "Acquire Deep Knowledge", detail: "Read through short eco-tech topic cards and complete active assessments/interactive quizzes." },
            { phase: "03", step: "Active Challenge Pledges", detail: "Select easy, medium, and difficult weekly tasks to reduce actual plastic bottle use and practice zero-waste logistics." },
            { phase: "04", step: "Streak Synchronizers", detail: "Validate carbon prevented from landfills daily to power up your active XP count and multiply multipliers." },
            { phase: "05", step: "Architect Leadership", detail: "Redeem high scores to obtain biological architect badges, leveling up your profile for world-wide ranking." },
          ].map((item, index) => (
            <motion.div 
              key={item.phase}
              initial={{ opacity: 0, x: -15 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative group"
            >
              {/* Timeline bubble bullet */}
              <div className="absolute -left-[45px] md:-left-[61px] top-1 h-8 w-8 rounded-full bg-dark-950 border border-white/15 flex items-center justify-center group-hover:border-eco-500/50 transition-colors">
                <span className="text-xs font-mono text-eco-400 font-bold">{item.phase}</span>
              </div>
              <h3 className="text-xl font-bold tracking-tight text-white group-hover:text-eco-300 transition-colors uppercase">{item.step}</h3>
              <p className="text-sm md:text-base text-slate-400 mt-2 leading-relaxed">{item.detail}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Plastic Awareness - Infographic Statistics */}
      <section className="px-6 py-16 max-w-7xl mx-auto border-t border-white/10 relative">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <span className="text-red-400 font-black text-xs uppercase tracking-[0.2em] block mb-4">GLOBAL POLLUTION FOOTPRINT</span>
            <h2 className="text-4xl md:text-6xl font-black uppercase italic tracking-tighter text-white mb-6">The Microplastic Accumulation Emergency</h2>
            <p className="text-slate-400 text-base md:text-lg leading-relaxed mb-8">
              Industrial chemical production of plastics is accelerating. Because polymers do not break down into organic nutrients, they fragment into microscopic vectors that bio-accumulate directly in wildlife, aquifers, and human tissues.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="p-2.5 rounded-xl bg-red-400/10 text-red-400 font-bold border border-red-500/20">
                  <AlertTriangle size={18} />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white uppercase">8+ Million Metric Tons</h4>
                  <p className="text-xs text-slate-400 mt-0.5">Dumped into Earth’s marine oceans annually.</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-2.5 rounded-xl bg-orange-400/10 text-orange-400 font-bold border border-orange-500/20">
                  <BarChart3 size={18} />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white uppercase">Only 9% Successfully Recycled</h4>
                  <p className="text-xs text-slate-400 mt-0.5">The remaining 91% decomposes in landfills or natural aquifers.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-[2rem] p-6 hover:border-red-500/30 transition-all relative overflow-hidden group">
              <span className="absolute right-4 top-4 text-[10px] uppercase tracking-widest text-[#ef4444] font-bold">Severe</span>
              <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-1 block">Weekly Intake</span>
              <h3 className="text-3xl font-black italic text-red-500">5 <span className="text-sm italic font-normal text-slate-500">grams</span></h3>
              <p className="text-white font-bold mt-3 text-sm">Consumed per person</p>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">Equivalent to consuming the full weight of a thermoplastic credit card every 7 days through polluted seafood and water.</p>
            </div>

            <div className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-[2rem] p-6 hover:border-sky-500/30 transition-all relative overflow-hidden group">
              <span className="absolute right-4 top-4 text-[10px] uppercase tracking-widest text-[#0ea5e9] font-bold">Progress</span>
              <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-1 block">CO2 Diverted</span>
              <h3 className="text-3xl font-black italic text-cyan-400">3.2 <span className="text-sm italic font-normal text-slate-500">Tons</span></h3>
              <p className="text-white font-bold mt-3 text-sm">Prevented carbon displacement</p>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">Sourced by switching industrial packaging to zero-plastic cellulose or starch-based materials.</p>
            </div>

            <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 backdrop-blur-lg border border-white/10 rounded-[2rem] p-6 col-span-1 md:col-span-2 hover:border-eco-500/30 transition-all relative overflow-hidden group">
              <span className="absolute right-4 top-4 text-[10px] uppercase tracking-widest text-[#22c55e] font-bold font-mono">Efficiency</span>
              <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-1 block">Conservation</span>
              <h3 className="text-3xl font-black italic text-eco-400">94% <span className="text-sm italic font-normal text-slate-500">Savings</span></h3>
              <p className="text-white font-bold mt-2 text-sm">Industrial Energy Conservation Ratio</p>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed font-sans">Processing recycled plastic consumes up to 94% less biological energy than extraction and processing of virgin petroleum oil monomers.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-6 py-16 max-w-5xl mx-auto text-center relative pointer-events-auto">
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 p-8 md:p-12 rounded-[2.5rem] relative overflow-hidden shadow-[0_20px_45px_rgba(2,6,23,0.6)]">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-eco-500/5 rounded-full blur-[90px] pointer-events-none" />
          
          <h2 className="text-4xl md:text-6xl font-black uppercase italic tracking-tighter text-white mb-6">Begin Your Environmental Pledge</h2>
          <p className="text-slate-400 text-base md:text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
            Take on daily and weekly goals in our plastic sandbox. Gain badges, inspect your progress status, and cultivate long-term eco-healthy habits.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {user ? (
              <Link 
                to="/challenge" 
                className="px-8 py-4 bg-eco-400 text-slate-950 font-black rounded-2xl flex items-center justify-center gap-3 hover:bg-eco-300 transition-colors uppercase tracking-tight shadow-xl shadow-eco-500/20 group"
              >
                <span>Launch Challenge Modules</span>
                <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
              </Link>
            ) : (
              <>
                <Link 
                  to="/signup" 
                  className="px-8 py-4 bg-eco-400 text-slate-950 font-black rounded-2xl flex items-center justify-center gap-3 hover:bg-eco-300 transition-colors uppercase tracking-tight shadow-xl shadow-eco-500/20 group"
                >
                  <span>Build For Free</span>
                  <ArrowRight size={18} className="transition-transform group-hover:translate-x-1" />
                </Link>
                <Link 
                  to="/login" 
                  className="px-8 py-4 bg-slate-800/50 backdrop-blur-md border border-white/10 text-white font-bold rounded-2xl hover:bg-white/10 transition-colors uppercase tracking-tight flex items-center justify-center"
                >
                  Sign In with Existing Session
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-dark-950/40 py-16 px-6 relative pb-28 md:pb-32">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 text-left">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <Leaf className="text-eco-400" size={24} />
              <span className="font-black text-lg tracking-tighter uppercase italic text-white">Plastic Life Simulation</span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              We develop futuristic sandbox tools focused on analyzing polymer decay indices, tracking carbon offsets, and encouraging organic consumer decisions.
            </p>
          </div>

          <div>
            <h4 className="font-black text-xs uppercase tracking-[0.2em] text-white mb-4">Sandbox Links</h4>
            <ul className="space-y-3">
              <li><Link to="/" className="text-sm text-slate-400 hover:text-eco-400 transition-colors">Home Sandbox</Link></li>
              <li><Link to="/learn" className="text-sm text-slate-400 hover:text-eco-400 transition-colors">Topic Catalog</Link></li>
              <li><Link to="/challenge" className="text-sm text-slate-400 hover:text-eco-400 transition-colors">Missions & Quizzes</Link></li>
              <li><Link to="/profile" className="text-sm text-slate-400 hover:text-eco-400 transition-colors">Eco Profile</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-black text-xs uppercase tracking-[0.2em] text-white mb-4">About Platform</h4>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Designed as a premium client-side eco-learning showcase. Formulated with local persistence state.
            </p>
            <span className="text-[10px] font-mono text-eco-400/60 bg-eco-400/5 border border-eco-500/10 px-2 py-1 rounded block w-fit">
              UTC ACTIVE: 2026-06-12
            </span>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-white/10 text-center flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <p>© 2026 Plastic Life Simulation Platform. Every biological choice matters.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-eco-400 transition-colors">Privacy Protocols</a>
            <a href="#" className="hover:text-eco-400 transition-colors">Terms of Interface</a>
          </div>
        </div>
      </footer>
    </div>
  );
};
