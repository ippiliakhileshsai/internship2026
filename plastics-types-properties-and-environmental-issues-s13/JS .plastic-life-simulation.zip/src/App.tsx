import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { Learn } from './pages/Learn';
import { Challenge } from './pages/Challenge';
import { Profile } from './pages/Profile';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { ForgotPassword } from './pages/ForgotPassword';

// Protected Route Shield
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-dark-950 text-white flex items-center justify-center">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-eco-500 border-t-transparent" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

// Route and Navbar alignment Layout helper
const AppContent: React.FC = () => {
  const { user } = useAuth();
  const location = useLocation();
  
  // Decide whether to render the floating navbar
  // Hide navbar on auth screens
  const hideNavbarRoutes = ['/login', '/signup', '/forgot-password'];
  const showNav = !hideNavbarRoutes.some(path => location.pathname.startsWith(path));

  return (
    <div className="min-h-screen bg-dark-950 text-white font-sans selection:bg-eco-500/30 overflow-x-hidden">
      {/* High-quality top eco status hub bar for global header navigation feedback */}
      <header className="sticky top-0 z-40 px-6 py-4 bg-dark-950/80 backdrop-blur-xl border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-eco-400 to-teal-600 rounded-lg flex items-center justify-center shadow-lg shadow-eco-500/10">
            <svg className="w-4.5 h-4.5 text-slate-900" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
            </svg>
          </div>
          <h1 className="text-lg font-black tracking-tighter uppercase italic text-white flex items-center gap-1.5">
            Plastic <span className="text-eco-400">Life</span>
          </h1>
        </div>

        {user ? (
          <div className="flex items-center gap-4">
            <div className="flex flex-col items-end">
              <span className="text-[9px] uppercase tracking-widest text-eco-400 font-extrabold">Current Level</span>
              <span className="text-sm font-mono font-bold text-white">LVL {user.level}</span>
            </div>
            <div className="h-8 w-8 rounded-full border-2 border-eco-500/30 p-0.5">
              <div className="w-full h-full rounded-full bg-slate-800 flex items-center justify-center font-bold text-[11px] text-white uppercase">
                {user.name ? user.name.slice(0, 2) : 'JD'}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-mono text-eco-400 bg-eco-500/10 border border-eco-500/20 px-2 py-0.5 rounded-md font-extrabold">DEMO ACTIVE</span>
          </div>
        )}
      </header>

      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        
        <Route path="/" element={<Home />} />
        <Route path="/learn" element={<Learn />} />
        
        <Route 
          path="/challenge" 
          element={
            <ProtectedRoute>
              <Challenge />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/profile" 
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          } 
        />
        
        {/* Wildcard Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

      {/* Shared Bottom Float Navbar */}
      {showNav && <Navbar />}
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}
