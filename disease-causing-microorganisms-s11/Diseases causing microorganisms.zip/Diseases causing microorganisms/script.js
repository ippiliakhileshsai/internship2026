const page = document.body.dataset.page;

const quizQuestions = [
  {
    question: "Which type of microorganism can cause strep throat?",
    options: ["Virus", "Bacterium", "Plant", "Algae"],
    answer: "Bacterium",
    detail: "Strep throat is caused by bacteria, not viruses."
  },
  {
    question: "Which place usually has fresher air?",
    options: ["A packed closed room", "Outside in open air", "A sealed closet", "Under a blanket fort"],
    answer: "Outside in open air",
    detail: "Fresh outdoor air helps move droplets away faster."
  },
  {
    question: "What should you use to cover a cough?",
    options: ["Your elbow or a tissue", "Your hand and then high-fives", "A toy", "Nothing at all"],
    answer: "Your elbow or a tissue",
    detail: "Covering coughs helps stop droplets from spreading as far."
  },
  {
    question: "Why do people wash their hands with soap?",
    options: ["To make germs slide around", "To remove germs", "To color their skin", "To make food taste better"],
    answer: "To remove germs",
    detail: "Soap helps lift germs away so water can wash them off."
  },
  {
    question: "If you feel sick, what is a smart choice?",
    options: ["Rest at home", "Share every snack", "Visit everyone", "Hide that you feel bad"],
    answer: "Rest at home",
    detail: "Resting at home helps your body heal and protects others too."
  }
];

const badgeRules = [
  { name: "Microbe Detective", minimum: 2, message: "You spotted important microbe clues." },
  { name: "Fresh Air Expert", minimum: 4, message: "You know how to help spaces stay safer." },
  { name: "Hygiene Pro", minimum: 5, message: "Perfect score. Your health habits are looking strong." }
];

const gameState = {
  score: 0,
  lives: 5,
  level: 1,
  running: false,
  spawnTimer: null,
  levelTimer: null,
  multiplierUntil: 0,
  freezeUntil: 0,
  boardRect: null
};

let quizIndex = 0;
let quizScore = 0;
let quizLocked = false;

function setActiveNavLink(id) {
  const navLinks = [...document.querySelectorAll(".site-nav a[href^='#']")];

  navLinks.forEach((link) => {
    const isActive = link.getAttribute("href") === `#${id}`;
    link.classList.toggle("is-active", isActive);
  });
}

function setupMenu() {
  const button = document.getElementById("menuToggle");
  const nav = document.getElementById("siteNav");

  if (!button || !nav) {
    return;
  }

  button.addEventListener("click", () => {
    const expanded = button.getAttribute("aria-expanded") === "true";
    button.setAttribute("aria-expanded", String(!expanded));
    nav.classList.toggle("open");
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      if (window.matchMedia("(max-width: 760px)").matches) {
        nav.classList.remove("open");
        button.setAttribute("aria-expanded", "false");
      }
    });
  });
}

function setupCursor() {
  const cursor = document.getElementById("virusCursor");

  if (!cursor || window.matchMedia("(pointer: coarse)").matches) {
    return;
  }

  let targetX = window.innerWidth / 2;
  let targetY = window.innerHeight / 2;
  let currentX = targetX;
  let currentY = targetY;
  let rafId = null;

  const render = () => {
    currentX += (targetX - currentX) * 0.22;
    currentY += (targetY - currentY) * 0.22;
    cursor.style.left = `${currentX}px`;
    cursor.style.top = `${currentY}px`;

    if (Math.abs(targetX - currentX) > 0.1 || Math.abs(targetY - currentY) > 0.1) {
      rafId = window.requestAnimationFrame(render);
    } else {
      rafId = null;
    }
  };

  const ensureRender = () => {
    if (rafId === null) {
      rafId = window.requestAnimationFrame(render);
    }
  };

  window.addEventListener("pointermove", (event) => {
    targetX = event.clientX;
    targetY = event.clientY;
    ensureRender();
  });

  window.addEventListener("pointerdown", () => {
    cursor.classList.remove("clicking");
    window.requestAnimationFrame(() => cursor.classList.add("clicking"));
  });

  cursor.addEventListener("animationend", () => {
    cursor.classList.remove("clicking");
  });

  if (page === "play") {
    const simulationFrame = document.querySelector(".simulation-frame");

    if (simulationFrame) {
      simulationFrame.addEventListener("mouseenter", () => {
        cursor.classList.add("hidden");
      });

      simulationFrame.addEventListener("mouseleave", () => {
        cursor.classList.remove("hidden");
      });
    }
  }
}

function setupLearnAnchors() {
  if (page !== "learn") {
    return;
  }

  const navLinks = [...document.querySelectorAll('.site-nav a[href^="#"]')];
  const sections = navLinks
    .map((link) => document.querySelector(link.getAttribute("href")))
    .filter(Boolean);

  if (!navLinks.length || !sections.length) {
    return;
  }

  setActiveNavLink("home");

  if (!("IntersectionObserver" in window)) {
    return;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      const activeEntry = entries
        .filter((entry) => entry.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];

      if (activeEntry) {
        setActiveNavLink(activeEntry.target.id);
      }
    },
    {
      threshold: [0.2, 0.35, 0.55],
      rootMargin: "-20% 0px -55% 0px"
    }
  );

  sections.forEach((section) => observer.observe(section));
}

function renderQuiz() {
  const questionNode = document.getElementById("quizQuestion");
  const optionsNode = document.getElementById("quizOptions");
  const progressNode = document.getElementById("quizProgress");
  const scoreNode = document.getElementById("quizScore");
  const feedbackNode = document.getElementById("quizFeedback");
  const nextButton = document.getElementById("nextQuestionBtn");

  if (!questionNode || !optionsNode || !progressNode || !scoreNode || !feedbackNode || !nextButton) {
    return;
  }

  const current = quizQuestions[quizIndex];
  questionNode.textContent = current.question;
  progressNode.textContent = `Question ${quizIndex + 1} of ${quizQuestions.length}`;
  scoreNode.textContent = `Score: ${quizScore}`;
  feedbackNode.textContent = "Choose the best answer.";
  optionsNode.innerHTML = "";
  quizLocked = false;

  current.options.forEach((option) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "quiz-option";
    button.textContent = option;

    button.addEventListener("click", () => {
      if (quizLocked) {
        return;
      }

      quizLocked = true;
      const isCorrect = option === current.answer;

      if (isCorrect) {
        quizScore += 1;
        scoreNode.textContent = `Score: ${quizScore}`;
        button.classList.add("correct");
        feedbackNode.textContent = `Nice work! ${current.detail}`;
      } else {
        button.classList.add("wrong");
        feedbackNode.textContent = `Not quite. ${current.detail}`;
      }

      [...optionsNode.children].forEach((choice) => {
        choice.disabled = true;

        if (choice.textContent === current.answer) {
          choice.classList.add("correct");
        }
      });

      updateBadges();
      nextButton.textContent = quizIndex === quizQuestions.length - 1 ? "See Results" : "Next Question";
    });

    optionsNode.appendChild(button);
  });
}

function updateBadges() {
  const badgeList = document.getElementById("badgeList");
  const badgeMessage = document.getElementById("badgeMessage");

  if (!badgeList || !badgeMessage) {
    return;
  }

  const badges = [...badgeList.children];
  const unlocked = badgeRules.filter((rule) => quizScore >= rule.minimum);

  badges.forEach((badge, index) => {
    const rule = badgeRules[index];
    if (!rule) {
      return;
    }

    const earned = quizScore >= rule.minimum;
    badge.classList.toggle("unlocked", earned);
    badge.classList.toggle("locked", !earned);
  });

  if (quizScore === quizQuestions.length) {
    badgeMessage.textContent = badgeRules[badgeRules.length - 1].message;
  } else if (unlocked.length > 0) {
    badgeMessage.textContent = unlocked[unlocked.length - 1].message;
  } else {
    badgeMessage.textContent = "Score points in the quiz to unlock shiny badges.";
  }
}

function setupQuiz() {
  if (page !== "learn") {
    return;
  }

  const nextButton = document.getElementById("nextQuestionBtn");
  const restartButton = document.getElementById("restartQuizBtn");

  if (!nextButton || !restartButton) {
    return;
  }

  nextButton.addEventListener("click", () => {
    if (!quizLocked) {
      document.getElementById("quizFeedback").textContent = "Pick an answer first so your team can score.";
      return;
    }

    if (quizIndex < quizQuestions.length - 1) {
      quizIndex += 1;
      renderQuiz();
      return;
    }

    const feedbackNode = document.getElementById("quizFeedback");
    const earned = badgeRules.filter((rule) => quizScore >= rule.minimum).map((rule) => rule.name);
    feedbackNode.textContent = earned.length
      ? `Quiz complete! You earned: ${earned.join(", ")}.`
      : "Quiz complete! Try again and unlock your first badge.";
  });

  restartButton.addEventListener("click", () => {
    quizIndex = 0;
    quizScore = 0;
    renderQuiz();
    updateBadges();
    nextButton.textContent = "Next Question";
  });

  renderQuiz();
  updateBadges();
}

function randomBetween(min, max) {
  return Math.random() * (max - min) + min;
}

function updateGameHud() {
  const scoreValue = document.getElementById("scoreValue");
  const livesValue = document.getElementById("livesValue");
  const levelValue = document.getElementById("levelValue");
  const statusText = document.getElementById("statusText");

  if (scoreValue) {
    scoreValue.textContent = String(gameState.score);
  }

  if (livesValue) {
    livesValue.textContent = String(gameState.lives);
  }

  if (levelValue) {
    levelValue.textContent = String(gameState.level);
  }

  if (statusText) {
    const boosted = Date.now() < gameState.multiplierUntil;
    const frozen = Date.now() < gameState.freezeUntil;
    if (!gameState.running) {
      statusText.textContent = "Waiting for the game to start.";
    } else if (boosted) {
      statusText.textContent = "Score boost active: double points.";
    } else if (frozen) {
      statusText.textContent = "Slow mode active: viruses are moving more slowly.";
    } else {
      statusText.textContent = "Click viruses before they slip away.";
    }
  }
}

function showOverlay(title, text, hidden = false) {
  const overlay = document.getElementById("gameOverlay");
  const overlayTitle = document.getElementById("overlayTitle");
  const overlayText = document.getElementById("overlayText");

  if (!overlay || !overlayTitle || !overlayText) {
    return;
  }

  overlay.classList.toggle("hidden", hidden);
  overlayTitle.textContent = title;
  overlayText.textContent = text;
}

function clearBoard() {
  const board = document.getElementById("gameBoard");
  if (!board) {
    return;
  }

  board.querySelectorAll(".virus-sprite, .power-up, .particle, .score-pop").forEach((node) => node.remove());
}

function loseLife() {
  if (!gameState.running) {
    return;
  }

  gameState.lives -= 1;
  updateGameHud();

  if (gameState.lives <= 0) {
    endGame("Game over", `Your final score was ${gameState.score}. Press Restart to defend the lab again.`);
  }
}

function burstParticles(board, x, y, color) {
  for (let index = 0; index < 8; index += 1) {
    const particle = document.createElement("span");
    particle.className = "particle";
    particle.style.left = `${x + randomBetween(-8, 8)}px`;
    particle.style.top = `${y + randomBetween(-8, 8)}px`;
    particle.style.background = color;
    particle.style.animationDelay = `${index * 0.02}s`;
    board.appendChild(particle);
    window.setTimeout(() => particle.remove(), 700);
  }
}

function spawnFloatingText(board, x, y, text, className = "positive") {
  const pop = document.createElement("span");
  pop.className = `score-pop ${className}`;
  pop.textContent = text;
  pop.style.left = `${x}px`;
  pop.style.top = `${y}px`;
  board.appendChild(pop);
  window.setTimeout(() => pop.remove(), 950);
}

function createVirus(board) {
  const virus = document.createElement("button");
  const face = document.createElement("span");
  const mouth = document.createElement("span");
  const size = randomBetween(58, 82);
  const boardWidth = Math.max(0, board.clientWidth - size);
  const boardHeight = Math.max(0, board.clientHeight - size);
  const duration = Date.now() < gameState.freezeUntil ? randomBetween(5200, 7000) : randomBetween(3200, 5200);

  virus.type = "button";
  virus.className = "virus-sprite";
  virus.style.width = `${size}px`;
  virus.style.height = `${size}px`;
  virus.style.left = `${randomBetween(10, Math.max(12, boardWidth - 10))}px`;
  virus.style.top = `${randomBetween(10, Math.max(12, boardHeight - 10))}px`;
  virus.style.animationDuration = `${randomBetween(1.2, 2.3)}s`;

  face.className = "virus-face";
  mouth.className = "virus-mouth";
  face.appendChild(mouth);
  virus.appendChild(face);

  const timeoutId = window.setTimeout(() => {
    if (!virus.isConnected) {
      return;
    }
    virus.remove();
    loseLife();
  }, duration);

  virus.addEventListener("click", () => {
    if (!gameState.running) {
      return;
    }

    const multiplier = Date.now() < gameState.multiplierUntil ? 2 : 1;
    const earned = 10 * multiplier;
    gameState.score += earned;
    updateGameHud();
    window.clearTimeout(timeoutId);
    burstParticles(board, virus.offsetLeft + size / 2, virus.offsetTop + size / 2, "#ff69b4");
    spawnFloatingText(board, virus.offsetLeft + size / 2 - 8, virus.offsetTop + 8, `+${earned}`);
    virus.remove();
  });

  board.appendChild(virus);
}

function applyPower(type) {
  if (type === "spark") {
    gameState.multiplierUntil = Date.now() + 7000;
  } else if (type === "freeze") {
    gameState.freezeUntil = Date.now() + 6000;
  } else if (type === "shield") {
    gameState.lives += 1;
  }

  updateGameHud();
}

function createPowerUp(board) {
  const types = ["spark", "freeze", "shield"];
  const labels = {
    spark: "Boost",
    freeze: "Slow",
    shield: "Shield"
  };
  const colors = {
    spark: "#ffd55a",
    freeze: "#8ee8ff",
    shield: "#5bffb7"
  };
  const type = types[Math.floor(Math.random() * types.length)];
  const power = document.createElement("button");
  const text = document.createElement("span");
  const size = 78;

  power.type = "button";
  power.className = `power-up ${type}`;
  power.style.left = `${randomBetween(12, Math.max(14, board.clientWidth - size - 12))}px`;
  power.style.top = `${randomBetween(12, Math.max(14, board.clientHeight - size - 12))}px`;
  text.textContent = labels[type];
  power.appendChild(text);

  const timeoutId = window.setTimeout(() => {
    power.remove();
  }, 5000);

  power.addEventListener("click", () => {
    if (!gameState.running) {
      return;
    }

    window.clearTimeout(timeoutId);
    applyPower(type);
    burstParticles(board, power.offsetLeft + size / 2, power.offsetTop + size / 2, colors[type]);
    spawnFloatingText(board, power.offsetLeft + size / 2 - 18, power.offsetTop + 8, labels[type], "power");
    power.remove();
  });

  board.appendChild(power);
}

function spawnEntity() {
  const board = document.getElementById("gameBoard");
  if (!board || !gameState.running) {
    return;
  }

  if (Math.random() < 0.23) {
    createPowerUp(board);
  } else {
    createVirus(board);
  }
}

function endGame(title, text) {
  gameState.running = false;
  window.clearInterval(gameState.spawnTimer);
  window.clearInterval(gameState.levelTimer);
  showOverlay(title, text, false);
  updateGameHud();
}

function startGame() {
  clearBoard();
  gameState.score = 0;
  gameState.lives = 5;
  gameState.level = 1;
  gameState.running = true;
  gameState.multiplierUntil = 0;
  gameState.freezeUntil = 0;

  updateGameHud();
  showOverlay("", "", true);
  spawnEntity();

  window.clearInterval(gameState.spawnTimer);
  window.clearInterval(gameState.levelTimer);

  gameState.spawnTimer = window.setInterval(() => {
    spawnEntity();
    if (Math.random() < 0.4 + gameState.level * 0.05) {
      spawnEntity();
    }
  }, 1050);

  gameState.levelTimer = window.setInterval(() => {
    if (!gameState.running) {
      return;
    }

    gameState.level += 1;
    updateGameHud();

    if (gameState.level >= 6) {
      endGame("You saved the lab!", `Amazing work. Your final score was ${gameState.score}.`);
    }
  }, 12000);
}

function setupGame() {
  if (page !== "play") {
    return;
  }

  const startButton = document.getElementById("startGameBtn");
  const restartButton = document.getElementById("restartGameBtn");

  if (!startButton || !restartButton) {
    return;
  }

  startButton.addEventListener("click", startGame);
  restartButton.addEventListener("click", startGame);
  updateGameHud();
  showOverlay("Ready to defend the lab?", "Press Start Game and zap microbes before they escape.", false);
}

function init() {
  setupMenu();
  setupCursor();
  setupLearnAnchors();
  setupQuiz();
  setupGame();
}

init();
